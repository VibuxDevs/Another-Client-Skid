package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;

public class Speed extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1);

    public Speed() {
        super("Speed", "Increases your movement speed on land", Category.MOVEMENT);
        addSetting(speed);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        if (mc.field_1724.field_6250 != 0 || mc.field_1724.field_6212 != 0) {
            float yaw = mc.field_1724.method_36454();
            double mx = 0, mz = 0;
            if (mc.field_1690.field_1894.method_1434()) {
                mx += Math.cos(Math.toRadians(yaw + 90));
                mz += Math.sin(Math.toRadians(yaw + 90));
            }
            if (mc.field_1690.field_1881.method_1434()) {
                mx -= Math.cos(Math.toRadians(yaw + 90));
                mz -= Math.sin(Math.toRadians(yaw + 90));
            }
            if (mc.field_1690.field_1913.method_1434()) {
                mx += Math.cos(Math.toRadians(yaw));
                mz += Math.sin(Math.toRadians(yaw));
            }
            if (mc.field_1690.field_1849.method_1434()) {
                mx -= Math.cos(Math.toRadians(yaw));
                mz -= Math.sin(Math.toRadians(yaw));
            }

            double len = Math.sqrt(mx * mx + mz * mz);
            if (len > 0) {
                // 0.2873 is the base movement speed value in Minecraft
                mx = (mx / len) * speed.getValue() * 0.2873;
                mz = (mz / len) * speed.getValue() * 0.2873;
            }

            mc.field_1724.method_18800(mx, mc.field_1724.method_18798().field_1351, mz);
        }
    }
}
