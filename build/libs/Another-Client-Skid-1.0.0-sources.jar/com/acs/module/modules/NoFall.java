package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_2828;

public class NoFall extends Module {
    public NoFall() {
        super("NoFall", "Prevents taking fall damage", Category.PLAYER);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1724.field_3944 == null) return;
        if (mc.field_1724.field_6017 > 2.0f) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_5911(true));
        }
    }
}
