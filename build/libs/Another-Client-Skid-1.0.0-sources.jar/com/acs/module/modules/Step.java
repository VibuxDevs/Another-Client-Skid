package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;
import net.minecraft.class_1322;
import net.minecraft.class_1324;
import net.minecraft.class_2960;
import net.minecraft.class_5134;

public class Step extends Module {
    private final NumberSetting height = new NumberSetting("Height", 1.0, 0.5, 3.0, 0.5);
    private static final class_2960 MODIFIER_ID = class_2960.method_60655("acs", "step_height");

    public Step() {
        super("Step", "Allows you to step up blocks automatically", Category.MOVEMENT);
        addSetting(height);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        class_1324 attribute = mc.field_1724.method_5996(class_5134.field_47761);
        if (attribute != null) {
            attribute.method_6200(MODIFIER_ID);
            double target = height.getValue();
            double diff = target - 0.6;
            if (diff > 0) {
                class_1322 modifier = new class_1322(MODIFIER_ID, diff, class_1322.class_1323.field_6328);
                attribute.method_26835(modifier);
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 == null) return;
        class_1324 attribute = mc.field_1724.method_5996(class_5134.field_47761);
        if (attribute != null) {
            attribute.method_6200(MODIFIER_ID);
        }
    }
}
