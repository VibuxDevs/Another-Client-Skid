package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;

public class AutoTotem extends Module {
    public AutoTotem() {
        super("AutoTotem", "Automatically equips totems in your offhand", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;

        // Skip if offhand is already a totem
        if (mc.field_1724.method_6079().method_7909() == class_1802.field_8288) return;

        // Find a totem in the main inventory
        class_1661 inv = mc.field_1724.method_31548();
        int totemSlot = -1;
        for (int i = 0; i < 36; i++) {
            if (inv.method_5438(i).method_7909() == class_1802.field_8288) {
                totemSlot = i;
                break;
            }
        }

        if (totemSlot != -1) {
            // Map PlayerInventory slot index to PlayerScreenHandler slot index
            int slotId = totemSlot;
            if (slotId < 9) {
                slotId += 36; // Hotbar slots mapping in PlayerScreenHandler
            }

            // Perform slot swap packet sequence
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slotId, 0, class_1713.field_7790, mc.field_1724);
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 45, 0, class_1713.field_7790, mc.field_1724);
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slotId, 0, class_1713.field_7790, mc.field_1724);
        }
    }
}
