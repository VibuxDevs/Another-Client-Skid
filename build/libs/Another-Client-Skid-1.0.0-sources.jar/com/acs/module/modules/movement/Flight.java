package com.acs.module.modules.movement;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;

public class Flight extends Module {

    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1);

    public Flight() {
        super("Flight", "Allows you to fly", Category.MOVEMENT);
        addSetting(speed);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;

        mc.field_1724.method_31549().field_7479 = true;
        mc.field_1724.method_31549().method_7248(speed.getValue().floatValue() * 0.05f);
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 == null) return;
        
        if (!mc.field_1724.method_7337() && !mc.field_1724.method_7325()) {
            mc.field_1724.method_31549().field_7479 = false;
        }
        mc.field_1724.method_31549().method_7248(0.05f); // default speed
    }
}
