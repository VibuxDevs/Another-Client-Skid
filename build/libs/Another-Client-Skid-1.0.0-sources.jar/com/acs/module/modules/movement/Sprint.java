package com.acs.module.modules.movement;

import com.acs.module.Category;
import com.acs.module.Module;

public class Sprint extends Module {
    public Sprint() {
        super("Sprint", "Automatically sprints", Category.MOVEMENT);
        addSetting(new com.acs.settings.ModeSetting("Mode", "Rage", java.util.Arrays.asList("Rage", "Legit")));
    }

    public void onTick() {
        if (mc.field_1724 != null && (mc.field_1724.field_6250 > 0 || mc.field_1724.field_6212 > 0)) {
            mc.field_1724.method_5728(true);
        }
    }
}
