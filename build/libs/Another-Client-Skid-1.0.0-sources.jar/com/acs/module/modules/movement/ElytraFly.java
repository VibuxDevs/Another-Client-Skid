package com.acs.module.modules.movement;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.ModeSetting;
import com.acs.settings.NumberSetting;
import java.util.Arrays;
import net.minecraft.class_243;
import net.minecraft.class_2848;
import net.minecraft.class_746;

public class ElytraFly extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Control", Arrays.asList("Control", "Bounce"));
    
    // Control Mode Settings
    private final NumberSetting speed = new NumberSetting("Speed", 1.5, 0.1, 5.0, 0.1);
    private final NumberSetting fallSpeed = new NumberSetting("Fall Speed", 0.0, 0.0, 0.2, 0.01);
    private final BooleanSetting autoFly = new BooleanSetting("Auto Fly", true);

    // Bounce Mode Settings
    private final NumberSetting bounceSpeed = new NumberSetting("Bounce Speed", 1.5, 0.5, 5.0, 0.1);
    private final NumberSetting bouncePitch = new NumberSetting("Bounce Pitch", 35.0, -90.0, 90.0, 1.0);
    private final BooleanSetting spoofPitch = new BooleanSetting("Spoof Pitch", true);

    // Infinite Durability
    private final BooleanSetting infiniteDurability = new BooleanSetting("Infinite Durability", true);
    private int swapTimer = 0;

    public ElytraFly() {
        super("ElytraFly", "Grants full control or bouncing mechanics over Elytra flight", Category.MOVEMENT);
        
        speed.setVisible(() -> mode.getValue().equals("Control"));
        fallSpeed.setVisible(() -> mode.getValue().equals("Control"));
        autoFly.setVisible(() -> mode.getValue().equals("Control"));
        bounceSpeed.setVisible(() -> mode.getValue().equals("Bounce"));
        bouncePitch.setVisible(() -> mode.getValue().equals("Bounce"));
        spoofPitch.setVisible(() -> mode.getValue().equals("Bounce"));

        addSetting(mode);
        addSetting(speed);
        addSetting(fallSpeed);
        addSetting(autoFly);
        addSetting(bounceSpeed);
        addSetting(bouncePitch);
        addSetting(spoofPitch);
        addSetting(infiniteDurability);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mc.field_1724.method_6128() && infiniteDurability.getValue()) {
            swapTimer++;
            if (swapTimer >= 15) {
                swapTimer = 0;
                if (mc.field_1761 != null) {
                    // Swap chestplate (slot 6) with hotbar slot 0, then swap it back
                    mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, 6, 0, net.minecraft.class_1713.field_7791, mc.field_1724);
                    mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, 6, 0, net.minecraft.class_1713.field_7791, mc.field_1724);
                    if (mc.method_1562() != null) {
                        mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
                    }
                }
            }
        }

        if (mode.getValue().equals("Bounce")) {
            if (!mc.field_1724.method_31548().method_7372(2).method_7909().toString().contains("elytra")) return;

            // Real Elytra hopping works by sending a START_FALL_FLYING packet immediately on jump/touchdown.
            // When on the ground, jump automatically. When in air, immediately deploy the elytra.
            if (mc.field_1724.method_24828()) {
                mc.field_1724.method_6043();
            } else if (mc.field_1724.method_18798().field_1351 < 0 && !mc.field_1724.method_6128()) {
                mc.field_1724.method_23669();
                if (mc.method_1562() != null) {
                    mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
                }
            }
        } else {
            if (autoFly.getValue() && !mc.field_1724.method_24828() && !mc.field_1724.method_6128() && mc.field_1724.field_6017 > 0.1f) {
                if (mc.method_1562() != null) {
                    mc.field_1724.method_23669();
                    mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
                }
            }
        }
    }

    public void handleTravel(class_746 player) {
        if (mode.getValue().equals("Bounce")) {
            handleBounceMode(player);
        } else {
            handleControlMode(player);
        }
    }

    private void handleControlMode(class_746 player) {
        double currentSpeed = speed.getValue();
        
        class_243 forward = class_243.method_1030(0, player.method_36454());
        class_243 right = class_243.method_1030(0, player.method_36454() + 90);

        double velX = 0;
        double velY = -fallSpeed.getValue();
        double velZ = 0;

        if (mc.field_1690.field_1903.method_1434()) velY += currentSpeed;
        if (mc.field_1690.field_1832.method_1434()) velY -= currentSpeed;

        if (mc.field_1690.field_1894.method_1434()) {
            velX += forward.field_1352 * currentSpeed;
            velZ += forward.field_1350 * currentSpeed;
        }
        if (mc.field_1690.field_1881.method_1434()) {
            velX -= forward.field_1352 * currentSpeed;
            velZ -= forward.field_1350 * currentSpeed;
        }
        if (mc.field_1690.field_1849.method_1434()) {
            velX += right.field_1352 * currentSpeed;
            velZ += right.field_1350 * currentSpeed;
        }
        if (mc.field_1690.field_1913.method_1434()) {
            velX -= right.field_1352 * currentSpeed;
            velZ -= right.field_1350 * currentSpeed;
        }

        player.method_18800(velX, velY, velZ);
        player.method_5784(net.minecraft.class_1313.field_6308, player.method_18798());
    }

    private void handleBounceMode(class_746 player) {
        if (spoofPitch.getValue() && player.method_6128()) {
            player.method_36457(bouncePitch.getValue().floatValue());
        }

        double currentSpeed = bounceSpeed.getValue();
        class_243 forward = class_243.method_1030(0, player.method_36454());
        class_243 right = class_243.method_1030(0, player.method_36454() + 90);

        double velX = 0;
        double velZ = 0;

        boolean moving = mc.field_1690.field_1894.method_1434() || mc.field_1690.field_1881.method_1434() || 
                         mc.field_1690.field_1913.method_1434() || mc.field_1690.field_1849.method_1434();

        if (moving) {
            if (mc.field_1690.field_1894.method_1434()) {
                velX += forward.field_1352;
                velZ += forward.field_1350;
            }
            if (mc.field_1690.field_1881.method_1434()) {
                velX -= forward.field_1352;
                velZ -= forward.field_1350;
            }
            if (mc.field_1690.field_1849.method_1434()) {
                velX += right.field_1352;
                velZ += right.field_1350;
            }
            if (mc.field_1690.field_1913.method_1434()) {
                velX -= right.field_1352;
                velZ -= right.field_1350;
            }

            class_243 moveDir = new class_243(velX, 0, velZ).method_1029();
            velX = moveDir.field_1352 * currentSpeed;
            velZ = moveDir.field_1350 * currentSpeed;
        }

        // To maintain the e-bounce speed without fireworks, we must preserve horizontal velocity.
        // If we're flying, we bypass downward gravity to keep ourselves aerodynamic until touchdown,
        // preventing the vanilla drag from kicking in.
        double velY = player.method_18798().field_1351;
        if (player.method_6128()) {
            // Apply slight downward glide slope to make the e-bounce look legitimate to server anti-cheats,
            // while preserving forward speed vectors.
            velY = -0.01;
        } else {
            // Standard falling physics
            velY -= 0.08;
            if (velY < -3.0) velY = -3.0;
        }

        player.method_18800(velX, velY, velZ);
        player.method_5784(net.minecraft.class_1313.field_6308, player.method_18798());
    }
}
