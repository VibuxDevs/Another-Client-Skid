package com.acs.module.modules.movement;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;
import net.minecraft.class_1324;
import net.minecraft.class_5134;

public class Step extends Module {

    private final NumberSetting height = new NumberSetting("Height", 2.0, 1.0, 4.0, 0.5);

    public Step() {
        super("Step", "Allows you to step up blocks instantly", Category.MOVEMENT);
        addSetting(height);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        
        class_1324 attribute = mc.field_1724.method_5996(class_5134.field_47761);
        if (attribute != null) {
            attribute.method_6192(height.getValue().floatValue());
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 != null) {
            class_1324 attribute = mc.field_1724.method_5996(class_5134.field_47761);
            if (attribute != null) {
                attribute.method_6192(0.6f); // Default Minecraft step height
            }
        }
    }
}
