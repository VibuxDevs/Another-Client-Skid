package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;
import com.acs.settings.ModeSetting;
import java.util.Arrays;

public class Fly extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Vanilla", Arrays.asList("Vanilla", "Velocity"));
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1);

    public Fly() {
        super("Fly", "Allows you to fly or glide in the air", Category.MOVEMENT);
        addSetting(mode);
        addSetting(speed);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        if (mode.getValue().equals("Vanilla")) {
            mc.field_1724.method_31549().field_7479 = true;
            mc.field_1724.method_31549().method_7248(speed.getValue().floatValue() * 0.05f);
        } else if (mode.getValue().equals("Velocity")) {
            mc.field_1724.method_31549().field_7479 = false;
            double s = speed.getValue();
            double mx = 0, mz = 0;
            
            // Calculate movement vectors based on player rotation
            float yaw = mc.field_1724.method_36454();
            if (mc.field_1690.field_1894.method_1434()) {
                mx += Math.cos(Math.toRadians(yaw + 90));
                mz += Math.sin(Math.toRadians(yaw + 90));
            }
            if (mc.field_1690.field_1881.method_1434()) {
                mx -= Math.cos(Math.toRadians(yaw + 90));
                mz -= Math.sin(Math.toRadians(yaw + 90));
            }
            if (mc.field_1690.field_1913.method_1434()) {
                mx += Math.cos(Math.toRadians(yaw));
                mz += Math.sin(Math.toRadians(yaw));
            }
            if (mc.field_1690.field_1849.method_1434()) {
                mx -= Math.cos(Math.toRadians(yaw));
                mz -= Math.sin(Math.toRadians(yaw));
            }

            double my = 0;
            if (mc.field_1690.field_1903.method_1434()) my += s;
            if (mc.field_1690.field_1832.method_1434()) my -= s;

            // Normalize and apply speed
            double len = Math.sqrt(mx * mx + mz * mz);
            if (len > 0) {
                mx = (mx / len) * s;
                mz = (mz / len) * s;
            }

            mc.field_1724.method_18800(mx, my, mz);
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 == null) return;
        mc.field_1724.method_31549().field_7479 = false;
        if (!mc.field_1724.method_7337()) {
            mc.field_1724.method_31549().field_7478 = false;
        }
    }
}
