package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

public class KillAura extends Module {
    public KillAura() {
        super("KillAura", "Attacks players around you", Category.COMBAT);
    }

    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1657 && entity != mc.field_1724) {
                if (mc.field_1724.method_5739(entity) <= 4.0f) {
                    mc.field_1761.method_2918(mc.field_1724, entity);
                    mc.field_1724.method_6104(class_1268.field_5808);
                    break;
                }
            }
        }
    }
}
