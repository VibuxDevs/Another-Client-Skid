package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.NumberSetting;
import com.acs.utils.FriendManager;
import net.minecraft.class_1268;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2848;

public class MaceBot extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 1.5, 0.5, 5.0, 0.1);
    private final NumberSetting height = new NumberSetting("HeightOffset", 15.0, 5.0, 30.0, 1.0);
    private final BooleanSetting useFireworks = new BooleanSetting("UseFireworks", true);

    private int fireworkCooldown = 0;

    public MaceBot() {
        super("MaceBot", "Automatically flies with Elytra and drops on players to Mace them", Category.EXPLOITS);
        addSetting(speed);
        addSetting(height);
        addSetting(useFireworks);
    }

    @Override
    public void onEnable() {
        fireworkCooldown = 0;
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.field_1761 == null) return;

        if (fireworkCooldown > 0) {
            fireworkCooldown--;
        }

        // Ensure player is holding or selects the Mace
        int maceSlot = -1;
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_49814) {
                maceSlot = i;
                break;
            }
        }
        if (maceSlot != -1) {
            mc.field_1724.method_31548().field_7545 = maceSlot;
        } else {
            // No Mace found in hotbar, cannot exploit
            return;
        }

        // Check if Elytra is equipped
        boolean hasElytra = mc.field_1724.method_6118(class_1304.field_6174).method_7909() == class_1802.field_8833;
        if (!hasElytra) return;

        // Auto-activate Elytra
        if (!mc.field_1724.method_6128()) {
            mc.field_1724.method_6043();
            mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2848.class_2849.field_12982));
            return;
        }

        // Find nearest target player (not self, not friend)
        class_1657 target = null;
        double nearestDist = Double.MAX_VALUE;

        for (class_1657 entity : mc.field_1687.method_18456()) {
            if (entity == mc.field_1724) continue;
            if (FriendManager.INSTANCE.isFriend(entity.method_5477().getString())) continue;
            if (!entity.method_5805()) continue;

            double dist = mc.field_1724.method_5739(entity);
            if (dist < nearestDist) {
                nearestDist = dist;
                target = entity;
            }
        }

        if (target == null) return;

        double dx = target.method_23317() - mc.field_1724.method_23317();
        double dy = (target.method_23318() + height.getValue()) - mc.field_1724.method_23318();
        double dz = target.method_23321() - mc.field_1724.method_23321();
        double horizontalDist = Math.sqrt(dx * dx + dz * dz);

        if (horizontalDist < 2.0) {
            // Directly above target, dive down fast
            mc.field_1724.method_18800(0, -2.0, 0);
            
            // Aim straight down
            mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
            mc.field_1724.method_36457(90.0f);
        } else {
            // Check if we need to boost height using fireworks
            if (useFireworks.getValue() && mc.field_1724.method_23318() < target.method_23318() + height.getValue() - 2.0 && fireworkCooldown == 0) {
                int fireworkSlot = -1;
                for (int i = 0; i < 9; i++) {
                    if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8639) {
                        fireworkSlot = i;
                        break;
                    }
                }

                if (fireworkSlot != -1) {
                    int prevSlot = mc.field_1724.method_31548().field_7545;
                    mc.field_1724.method_31548().field_7545 = fireworkSlot;
                    mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
                    mc.field_1724.method_31548().field_7545 = prevSlot;
                    fireworkCooldown = 30; // 1.5 second cooldown between boosts
                    return;
                }
            }

            // Glide toward the Y-offset point above the target
            double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (dist > 0) {
                double s = speed.getValue();
                double vx = (dx / dist) * s;
                double vy = (dy / dist) * s;
                double vz = (dz / dist) * s;
                mc.field_1724.method_18800(vx, vy, vz);

                // Rotate body and head to face the waypoint
                float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
                float pitch = (float) -Math.toDegrees(Math.atan2(vy, Math.sqrt(vx * vx + vz * vz)));
                mc.field_1724.method_36456(yaw);
                mc.field_1724.method_36457(pitch);
            }
        }

        // Attack if target gets in reach during fall/dive
        if (mc.field_1724.method_5739(target) <= 4.0f) {
            mc.field_1761.method_2918(mc.field_1724, target);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }
}
