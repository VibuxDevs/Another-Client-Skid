package com.acs.module.modules.pvp;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_239;
import net.minecraft.class_3966;

public class TriggerBot extends Module {
    public TriggerBot() {
        super("TriggerBot", "Automatically attacks when looking at a living target", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null || mc.field_1765 == null) return;

        if (mc.field_1765.method_17783() == class_239.class_240.field_1331) {
            class_3966 hitResult = (class_3966) mc.field_1765;
            class_1297 entity = hitResult.method_17782();

            if (entity instanceof class_1309 && entity.method_5805() && entity != mc.field_1724) {
                if (mc.field_1724.method_7261(0.0f) >= 1.0f) {
                    mc.field_1761.method_2918(mc.field_1724, entity);
                    mc.field_1724.method_6104(class_1268.field_5808);
                }
            }
        }
    }
}
