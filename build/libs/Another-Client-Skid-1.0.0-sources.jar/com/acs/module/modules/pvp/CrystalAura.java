package com.acs.module.modules.pvp;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.NumberSetting;
import com.acs.utils.DamageUtils;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2879;
import net.minecraft.class_3532;
import net.minecraft.class_3965;

public class CrystalAura extends Module {

    public CrystalAura() {
        super("CrystalAura", "Automatically places and attacks end crystals", Category.COMBAT);
        initializeSettings();
    }

    public boolean attackEnabled     = true;
    public double  attackSpeed       = 20.0;
    public double  attackRange       = 6.0;
    public boolean instantAttack     = true;

    public boolean placeEnabled      = true;
    public double  placeSpeed        = 20.0;
    public double  placeRange        = 6.0;

    public boolean autoSwitch        = true;
    public double  minimumDamage     = 6.0;
    public double  maximumSelfDamage = 10.0;
    public double  lethalMultiplier  = 1.5;
    public boolean antiSuicide       = true;
    public double  enemyRange        = 10.0;
    public double  extrapolation     = 0.0;

    private long             lastAttackTime        = 0;
    private long             lastPlaceTime         = 0;
    private class_1511 targetCrystal         = null;
    private class_2338         targetPlacement       = null;
    private long             lastCpsUpdateTime     = 0;
    private int              crystalsHitThisSecond = 0;
    private double           currentCps            = 0.0;

    private void initializeSettings() {
        addSetting(new BooleanSetting("Attack Enabled",   attackEnabled));
        addSetting(new NumberSetting("Attack Speed",      attackSpeed,       0.1, 20.0, 0.5));
        addSetting(new NumberSetting("Attack Range",      attackRange,       0.0,  6.0, 0.5));
        addSetting(new BooleanSetting("Instant Attack",   instantAttack));
        addSetting(new BooleanSetting("Place Enabled",    placeEnabled));
        addSetting(new NumberSetting("Place Speed",       placeSpeed,        0.1, 20.0, 0.5));
        addSetting(new NumberSetting("Place Range",       placeRange,        0.0, 20.0, 0.5));
        addSetting(new BooleanSetting("Auto Switch",      autoSwitch));
        addSetting(new NumberSetting("Minimum Damage",    minimumDamage,     0.0, 20.0, 0.5));
        addSetting(new NumberSetting("Max Self Damage",   maximumSelfDamage, 0.0, 36.0, 0.5));
        addSetting(new NumberSetting("Lethal Multiplier", lethalMultiplier,  0.0,  2.0, 0.1));
        addSetting(new BooleanSetting("Anti Suicide",     antiSuicide));
        addSetting(new NumberSetting("Enemy Range",       enemyRange,        0.0, 50.0, 1.0));
        addSetting(new NumberSetting("Extrapolation",     extrapolation,     0.0, 20.0, 1.0));
    }

    @Override
    public void onEnable() {}

    @Override
    public void onDisable() {}

    @Override
    public void onTick() {
        syncSettings();
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (attackEnabled) attackCrystals();
        if (placeEnabled)  placeCrystals();
    }

    private void syncSettings() {
        for (com.acs.settings.Setting<?> setting : getSettings()) {
            String name  = setting.getName();
            Object value = setting.getValue();

            if (value instanceof Boolean b) {
                switch (name) {
                    case "Attack Enabled"  -> attackEnabled     = b;
                    case "Instant Attack"  -> instantAttack     = b;
                    case "Place Enabled"   -> placeEnabled      = b;
                    case "Auto Switch"     -> autoSwitch        = b;
                    case "Anti Suicide"    -> antiSuicide       = b;
                }
            } else if (value instanceof Double d) {
                switch (name) {
                    case "Attack Speed"      -> attackSpeed       = d;
                    case "Attack Range"      -> attackRange       = d;
                    case "Place Speed"       -> placeSpeed        = d;
                    case "Place Range"       -> placeRange        = d;
                    case "Minimum Damage"    -> minimumDamage     = d;
                    case "Max Self Damage"   -> maximumSelfDamage = d;
                    case "Lethal Multiplier" -> lethalMultiplier  = d;
                    case "Enemy Range"       -> enemyRange        = d;
                    case "Extrapolation"     -> extrapolation     = d;
                }
            }
        }
    }

    private void attackCrystals() {
        long currentTime = System.currentTimeMillis();
        long attackDelay = instantAttack ? 0 : (long) (1000.0 / attackSpeed);
        if (currentTime - lastAttackTime < attackDelay) return;

        class_1511 bestCrystal = null;
        float bestDamage = 0.0f;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1511 crystal)) continue;
            if (!crystal.method_5805()) continue;

            double distSq = crystal.method_5829().method_49271(mc.field_1724.method_33571());
            if (distSq > class_3532.method_33723(attackRange)) continue;
            if (!mc.field_1687.method_8621().method_11952(crystal.method_24515())) continue;

            float selfDamage = DamageUtils.calculateCrystalDamage(mc.field_1724, crystal.method_24515(), extrapolation);
            if (selfDamage > maximumSelfDamage) continue;
            if (antiSuicide && DamageUtils.isLethal(selfDamage, mc.field_1724)) continue;

            for (class_1657 enemy : mc.field_1687.method_18456()) {
                if (enemy == mc.field_1724 || !enemy.method_5805()) continue;
                if (mc.field_1724.method_5858(enemy) > class_3532.method_33723(enemyRange)) continue;

                float damage = DamageUtils.calculateCrystalDamage(enemy, crystal.method_24515(), extrapolation);
                if (!DamageUtils.isAboveMinimum(damage, minimumDamage)) continue;

                float effectiveDamage = DamageUtils.isLethal(damage, enemy)
                        ? damage * (float) lethalMultiplier
                        : damage;

                if (effectiveDamage > bestDamage) {
                    bestDamage = effectiveDamage;
                    bestCrystal = crystal;
                }
            }
        }

        if (bestCrystal != null && bestCrystal.method_5805()) {
            if (mc.method_1562() != null) {
                mc.method_1562().method_52787(
                        class_2824.method_34206(bestCrystal, mc.field_1724.method_5715()));
                mc.method_1562().method_52787(new class_2879(class_1268.field_5808));
            }
            lastAttackTime = currentTime;
            targetCrystal  = bestCrystal;
            updateCrystalHitCount();
        }
    }

    private void placeCrystals() {
        long currentTime = System.currentTimeMillis();
        long placeDelay  = (long) (1000.0 / placeSpeed);
        if (currentTime - lastPlaceTime < placeDelay) return;

        class_2338 bestPlacement  = null;
        float    bestDamage     = 0.0f;
        double   closestToEnemy = Double.MAX_VALUE;
        int      searchRadius   = (int) Math.ceil(placeRange);

        for (int x = -searchRadius; x <= searchRadius; x++) {
            for (int y = -searchRadius; y <= searchRadius; y++) {
                for (int z = -searchRadius; z <= searchRadius; z++) {
                    class_2338 position = mc.field_1724.method_24515().method_10069(x, y, z);

                    double distSq = mc.field_1724.method_19538().method_1025(
                            class_243.method_24954(position).method_1031(0.5, 1.0, 0.5));
                    if (distSq > class_3532.method_33723(placeRange)) continue;

                    if (!mc.field_1687.method_8621().method_11952(position)) continue;

                    if (mc.field_1687.method_8320(position).method_26204() != class_2246.field_10540 &&
                        mc.field_1687.method_8320(position).method_26204() != class_2246.field_9987) continue;

                    if (!mc.field_1687.method_8320(position.method_10084()).method_26215()) continue;

                    class_238 placementBox = new class_238(position.method_10084());
                    if (mc.field_1687.method_8335(null, placementBox).stream()
                            .anyMatch(e -> e.method_5805() && !(e instanceof class_1511))) continue;

                    float selfDamage = DamageUtils.calculateCrystalDamage(mc.field_1724, position, extrapolation);
                    if (selfDamage > maximumSelfDamage) continue;
                    if (antiSuicide && DamageUtils.isLethal(selfDamage, mc.field_1724)) continue;

                    for (class_1657 player : mc.field_1687.method_18456()) {
                        if (player == mc.field_1724 || !player.method_5805()) continue;
                        if (mc.field_1724.method_5858(player) > class_3532.method_33723(enemyRange)) continue;

                        float  damage      = DamageUtils.calculateCrystalDamage(player, position, extrapolation);
                        double distToEnemy = class_243.method_24953(position).method_1025(player.method_19538());

                        if (DamageUtils.isAboveMinimum(damage, minimumDamage)) {
                            if (damage > bestDamage || (damage == bestDamage && distToEnemy < closestToEnemy)) {
                                bestPlacement  = position;
                                bestDamage     = damage;
                                closestToEnemy = distToEnemy;
                            }
                        }
                    }
                }
            }
        }

        if (bestPlacement != null && bestDamage > 0) {
            boolean hasCrystal = mc.field_1724.method_6047().method_7909() == class_1802.field_8301 || mc.field_1724.method_6079().method_7909() == class_1802.field_8301;
            if (!hasCrystal && autoSwitch) {
                findAndSwitchToCrystal();
                hasCrystal = mc.field_1724.method_6047().method_7909() == class_1802.field_8301 || mc.field_1724.method_6079().method_7909() == class_1802.field_8301;
            }
            if (hasCrystal) {
                placeCrystalAtPosition(bestPlacement);
                lastPlaceTime   = currentTime;
                targetPlacement = bestPlacement;
            }
        }
    }

    private void placeCrystalAtPosition(class_2338 position) {
        if (mc.method_1562() == null || mc.field_1724 == null) return;
        class_1268 hand = mc.field_1724.method_6079().method_7909() == class_1802.field_8301
                ? class_1268.field_5810
                : class_1268.field_5808;

        class_3965 hitResult = new class_3965(
                class_243.method_24953(position).method_1031(0, 0.5, 0),
                class_2350.field_11036,
                position,
                false);

        mc.field_1761.method_2896(mc.field_1724, hand, hitResult);
        mc.field_1724.method_6104(hand);
    }

    private void findAndSwitchToCrystal() {
        for (int i = 0; i < 9; i++) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == class_1802.field_8301) {
                mc.field_1724.method_31548().field_7545 = i;
                if (mc.method_1562() != null) {
                    mc.method_1562().method_52787(new net.minecraft.class_2868(i));
                }
                return;
            }
        }
    }

    private void updateCrystalHitCount() {
        long currentTime = System.currentTimeMillis();
        crystalsHitThisSecond++;
        if (currentTime - lastCpsUpdateTime > 1000) {
            currentCps            = crystalsHitThisSecond;
            crystalsHitThisSecond = 0;
            lastCpsUpdateTime     = currentTime;
        }
    }

    public double getCurrentCps() {
        return currentCps;
    }
}