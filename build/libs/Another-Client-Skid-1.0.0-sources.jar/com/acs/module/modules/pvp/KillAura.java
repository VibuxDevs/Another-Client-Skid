package com.acs.module.modules.pvp;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.NumberSetting;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;

public class KillAura extends Module {
    private final NumberSetting range = new NumberSetting("Range", 4.0, 1.0, 6.0, 0.1);
    private final BooleanSetting waitCooldown = new BooleanSetting("Wait Cooldown", true);
    private final BooleanSetting players = new BooleanSetting("Players", true);
    private final BooleanSetting mobs = new BooleanSetting("Mobs", false);
    private final BooleanSetting animals = new BooleanSetting("Animals", false);

    public KillAura() {
        super("KillAura", "Attacks entities around you", Category.COMBAT);
        addSetting(range);
        addSetting(waitCooldown);
        addSetting(players);
        addSetting(mobs);
        addSetting(animals);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (waitCooldown.getValue() && mc.field_1724.method_7261(0.5f) < 1.0f) return;

        List<class_1297> targets = StreamSupport.stream(mc.field_1687.method_18112().spliterator(), false)
                .filter(this::isValidTarget)
                .sorted(Comparator.comparingDouble(e -> mc.field_1724.method_5739(e)))
                .collect(Collectors.toList());

        if (!targets.isEmpty()) {
            class_1297 target = targets.get(0);
            mc.field_1761.method_2918(mc.field_1724, target);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private boolean isValidTarget(class_1297 entity) {
        if (entity == mc.field_1724 || !entity.method_5805()) return false;
        if (mc.field_1724.method_5739(entity) > range.getValue()) return false;

        if (entity instanceof class_1657 && players.getValue()) return true;
        if (entity instanceof class_1588 && mobs.getValue()) return true;
        if (entity instanceof class_1429 && animals.getValue()) return true;

        return false;
    }
}
