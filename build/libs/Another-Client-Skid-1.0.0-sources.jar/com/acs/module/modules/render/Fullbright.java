package com.acs.module.modules.render;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.mixin.SimpleOptionAccessor;

import java.lang.reflect.Field;

public class Fullbright extends Module {
    private double savedGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Makes everything bright", Category.RENDER);
    }

    @Override
    public void onEnable() {
        if (mc.field_1690 != null) {
            savedGamma = mc.field_1690.method_42473().method_41753();
            setGamma(16.0);
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1690 != null) {
            setGamma(16.0);
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1690 != null) {
            setGamma(savedGamma);
        }
    }

    private void setGamma(double value) {
        try {
            SimpleOptionAccessor accessor = (SimpleOptionAccessor) (Object) mc.field_1690.method_42473();
            accessor.setValueDirect(value);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
