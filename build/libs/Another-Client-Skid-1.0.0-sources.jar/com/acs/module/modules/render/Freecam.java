package com.acs.module.modules.render;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_243;
import net.minecraft.class_745;

public class Freecam extends Module {

    private class_745 dummy;
    private class_243 savedPos;
    private float savedYaw;
    private float savedPitch;

    public Freecam() {
        super("Freecam", "Leaves your body and allows you to move freely", Category.RENDER);
    }

    @Override
    public void onEnable() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        
        savedPos = mc.field_1724.method_19538();
        savedYaw = mc.field_1724.method_36454();
        savedPitch = mc.field_1724.method_36455();

        dummy = new class_745(mc.field_1687, mc.field_1724.method_7334());
        dummy.method_5719(mc.field_1724);
        dummy.method_5857(mc.field_1724.method_5829());
        dummy.method_31548().method_7377(mc.field_1724.method_31548());
        
        mc.field_1687.method_53875(dummy);
        
        mc.field_1724.field_5960 = true;
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        
        mc.field_1724.field_5960 = false;
        if (savedPos != null) {
            mc.field_1724.method_5641(savedPos.field_1352, savedPos.field_1351, savedPos.field_1350, savedYaw, savedPitch);
        }
        
        if (dummy != null) {
            mc.field_1687.method_2945(dummy.method_5628(), net.minecraft.class_1297.class_5529.field_26999);
            dummy = null;
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        mc.field_1724.method_31549().field_7479 = true;
        mc.field_1724.field_5960 = true;
    }
}
