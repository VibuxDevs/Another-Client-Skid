package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_1297;

public class BoatPhase extends Module {
    public BoatPhase() {
        super("BoatPhase", "Allows riding vehicles (boats) to phase through solid blocks", Category.EXPLOITS);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        class_1297 vehicle = mc.field_1724.method_5854();
        if (vehicle != null) {
            vehicle.field_5960 = true;
            mc.field_1724.field_5960 = true;
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1724 == null) return;
        mc.field_1724.field_5960 = false;
        class_1297 vehicle = mc.field_1724.method_5854();
        if (vehicle != null) {
            vehicle.field_5960 = false;
        }
    }
}
