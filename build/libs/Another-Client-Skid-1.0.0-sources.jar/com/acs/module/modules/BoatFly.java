package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.NumberSetting;
import net.minecraft.class_1297;

public class BoatFly extends Module {
    private final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 5.0, 0.1);
    private final NumberSetting verticalSpeed = new NumberSetting("VerticalSpeed", 0.5, 0.1, 3.0, 0.1);
    private final BooleanSetting glide = new BooleanSetting("Glide", true);

    public BoatFly() {
        super("BoatFly", "Allows you to fly while riding a boat", Category.MOVEMENT);
        addSetting(speed);
        addSetting(verticalSpeed);
        addSetting(glide);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null) return;
        class_1297 vehicle = mc.field_1724.method_5854();
        if (vehicle == null) return;

        // Sync rotations to make steering easier
        vehicle.method_36456(mc.field_1724.method_36454());

        float yaw = mc.field_1724.method_36454();
        double mx = 0, mz = 0;
        if (mc.field_1690.field_1894.method_1434()) {
            mx += Math.cos(Math.toRadians(yaw + 90));
            mz += Math.sin(Math.toRadians(yaw + 90));
        }
        if (mc.field_1690.field_1881.method_1434()) {
            mx -= Math.cos(Math.toRadians(yaw + 90));
            mz -= Math.sin(Math.toRadians(yaw + 90));
        }
        if (mc.field_1690.field_1913.method_1434()) {
            mx += Math.cos(Math.toRadians(yaw));
            mz += Math.sin(Math.toRadians(yaw));
        }
        if (mc.field_1690.field_1849.method_1434()) {
            mx -= Math.cos(Math.toRadians(yaw));
            mz -= Math.sin(Math.toRadians(yaw));
        }

        double len = Math.sqrt(mx * mx + mz * mz);
        if (len > 0) {
            mx = (mx / len) * speed.getValue();
            mz = (mz / len) * speed.getValue();
        }

        double my = 0;
        if (mc.field_1690.field_1903.method_1434()) {
            my = verticalSpeed.getValue();
        } else if (mc.field_1690.field_1832.method_1434()) {
            my = -verticalSpeed.getValue();
        } else {
            if (glide.getValue()) {
                my = 0;
            } else {
                my = vehicle.method_18798().field_1351;
            }
        }

        vehicle.method_18800(mx, my, mz);
        
        // Reset fall distance to prevent damage on landing
        mc.field_1724.field_6017 = 0;
        vehicle.field_6017 = 0;
    }
}
