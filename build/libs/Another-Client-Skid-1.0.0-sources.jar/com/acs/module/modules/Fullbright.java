package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import java.lang.reflect.Field;
import net.minecraft.class_7172;

public class Fullbright extends Module {
    private double savedGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Makes everything bright", Category.RENDER);
    }

    @Override
    public void onEnable() {
        if (mc.field_1690 != null) {
            savedGamma = mc.field_1690.method_42473().method_41753();
            setGamma(16.0);
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1690 != null) {
            setGamma(16.0);
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1690 != null) {
            setGamma(savedGamma);
        }
    }

    @SuppressWarnings("unchecked")
    private void setGamma(double value) {
        try {
            class_7172<Double> gamma = mc.field_1690.method_42473();
            Field field = class_7172.class.getDeclaredField("value");
            field.setAccessible(true);
            field.set(gamma, value);
        } catch (Exception e) {
            // Reflection failed, try setValue anyway
            mc.field_1690.method_42473().method_41748(value);
        }
    }
}
