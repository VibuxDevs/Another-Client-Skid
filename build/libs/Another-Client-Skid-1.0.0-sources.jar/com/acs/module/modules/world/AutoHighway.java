package com.acs.module.modules.world;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.NumberSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class AutoHighway extends Module {

    private final NumberSetting width = new NumberSetting("Width", 3.0, 1.0, 5.0, 1.0);
    private final BooleanSetting buildWalls = new BooleanSetting("Build Walls", false);
    private final NumberSetting wallHeight = new NumberSetting("Wall Height", 2.0, 1.0, 4.0, 1.0);
    private final BooleanSetting autoWalk = new BooleanSetting("Auto Walk", true);
    private final BooleanSetting autoMine = new BooleanSetting("Auto Mine", true);

    private int startY;
    private class_2350 startDir = null;

    public AutoHighway() {
        super("AutoHighway", "Automatically builds and clears obsidian highways along axes", Category.WORLD);
        
        wallHeight.setVisible(() -> buildWalls.getValue());
        
        addSetting(width);
        addSetting(buildWalls);
        addSetting(wallHeight);
        addSetting(autoWalk);
        addSetting(autoMine);
    }

    @Override
    public void onEnable() {
        if (mc.field_1724 != null) {
            startY = mc.field_1724.method_24515().method_10264();
            startDir = mc.field_1724.method_5755();
            if (startDir == class_2350.field_11036 || startDir == class_2350.field_11033) {
                startDir = class_2350.field_11043;
            }
        }
    }

    @Override
    public void onDisable() {
        if (mc.field_1690 != null && mc.field_1690.field_1894 != null && autoWalk.getValue()) {
            mc.field_1690.field_1894.method_23481(false);
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null || startDir == null) return;

        if (autoWalk.getValue()) {
            mc.field_1724.method_36456(startDir.method_10144());
            mc.field_1690.field_1894.method_23481(true);
        }

        class_2338 playerPos = mc.field_1724.method_24515();
        class_2350 dir = startDir;

        int dx = 0;
        int dz = 0;
        if (dir == class_2350.field_11043 || dir == class_2350.field_11035) {
            dx = 1;
        } else {
            dz = 1;
        }

        int w = width.getValue().intValue();
        int minOffset = -w / 2;
        int maxOffset = w / 2;
        if (w % 2 == 0) {
            maxOffset = w / 2 - 1;
        }

        int checkAhead = 1;
        
        for (int i = minOffset; i <= maxOffset; i++) {
            int targetX = playerPos.method_10263() + dir.method_10148() * checkAhead + dx * i;
            int targetZ = playerPos.method_10260() + dir.method_10165() * checkAhead + dz * i;

            class_2338 buildPos = new class_2338(targetX, startY - 1, targetZ);

            // Replace floor if it is not Obsidian
            net.minecraft.class_2680 floorState = mc.field_1687.method_8320(buildPos);
            if (floorState.method_26204() != class_2246.field_10540) {
                if (autoMine.getValue()) {
                    mineBlockIfSolid(buildPos);
                }
                if (mc.field_1687.method_8320(buildPos).method_45474()) {
                    tryPlaceObsidian(buildPos);
                }
            }

            // Build walls or clear the walking path
            boolean isOuter = (i == minOffset || i == maxOffset);
            if (isOuter && buildWalls.getValue()) {
                int wh = wallHeight.getValue().intValue();
                for (int h = 0; h < wh; h++) {
                    class_2338 wallPos = new class_2338(targetX, startY + h, targetZ);
                    if (autoMine.getValue()) {
                        mineBlockIfSolid(wallPos);
                    }
                    if (mc.field_1687.method_8320(wallPos).method_45474()) {
                        tryPlaceObsidian(wallPos);
                    }
                }
            } else {
                if (autoMine.getValue()) {
                    mineBlockIfSolid(new class_2338(targetX, startY, targetZ));
                    mineBlockIfSolid(new class_2338(targetX, startY + 1, targetZ));
                    mineBlockIfSolid(new class_2338(targetX, startY + 2, targetZ));
                }
            }
        }
    }

    private void tryPlaceObsidian(class_2338 pos) {
        int obbySlot = getObsidianSlot();
        if (obbySlot != -1) {
            int oldSlot = mc.field_1724.method_31548().field_7545;
            if (oldSlot != obbySlot) {
                mc.field_1724.method_31548().field_7545 = obbySlot;
                mc.method_1562().method_52787(new net.minecraft.class_2868(obbySlot));
            }

            placeBlock(pos);

            if (oldSlot != obbySlot) {
                mc.field_1724.method_31548().field_7545 = oldSlot;
                mc.method_1562().method_52787(new net.minecraft.class_2868(oldSlot));
            }
        }
    }

    private void placeBlock(class_2338 pos) {
        if (mc.field_1761 == null || mc.field_1724 == null || mc.field_1687 == null) return;

        class_2350 placeDir = class_2350.field_11036;
        class_2338 placePos = pos;

        for (class_2350 d : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(d);
            if (!mc.field_1687.method_8320(neighbor).method_45474()) {
                placePos = neighbor;
                placeDir = d.method_10153();
                break;
            }
        }

        class_3965 hitResult = new class_3965(
                class_243.method_24953(placePos).method_1019(class_243.method_24954(placeDir.method_10163()).method_1021(0.5)),
                placeDir,
                placePos,
                false
        );
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private void mineBlockIfSolid(class_2338 pos) {
        if (mc.field_1687 == null || mc.field_1761 == null || mc.field_1724 == null) return;
        net.minecraft.class_2680 state = mc.field_1687.method_8320(pos);
        if (!state.method_26215() && !state.method_51176() && state.method_26214(mc.field_1687, pos) >= 0) {
            int toolSlot = getBestTool(pos);
            if (toolSlot != -1) {
                int oldSlot = mc.field_1724.method_31548().field_7545;
                if (oldSlot != toolSlot) {
                    mc.field_1724.method_31548().field_7545 = toolSlot;
                    mc.method_1562().method_52787(new net.minecraft.class_2868(toolSlot));
                }
            }
            mc.field_1761.method_2902(pos, class_2350.field_11036);
            mc.field_1724.method_6104(class_1268.field_5808);
        }
    }

    private int getBestTool(class_2338 pos) {
        if (mc.field_1687 == null || mc.field_1724 == null) return -1;
        float bestSpeed = 1f;
        int bestSlot = -1;
        net.minecraft.class_2680 state = mc.field_1687.method_8320(pos);
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960()) {
                float speed = stack.method_7924(state);
                if (speed > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = i;
                }
            }
        }
        return bestSlot;
    }

    private int getObsidianSlot() {
        if (mc.field_1724 == null) return -1;
        // Search hotbar first
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == net.minecraft.class_1802.field_8281) {
                return i;
            }
        }
        // Search inventory and swap to slot 0
        for (int i = 9; i < 36; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == net.minecraft.class_1802.field_8281) {
                if (mc.field_1761 != null) {
                    mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, i, 0, net.minecraft.class_1713.field_7791, mc.field_1724);
                }
                return 0;
            }
        }
        return -1;
    }
}
