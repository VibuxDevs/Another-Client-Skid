package com.acs.module.modules.world;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.BooleanSetting;
import com.acs.settings.NumberSetting;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_3965;

public class Scaffold extends Module {

    private final BooleanSetting tower = new BooleanSetting("Tower", true);
    private final NumberSetting extend = new NumberSetting("Extend", 0.0, 0.0, 5.0, 1.0);
    private final BooleanSetting keepY = new BooleanSetting("Keep Y", false);
    private final BooleanSetting safeWalk = new BooleanSetting("SafeWalk", true);

    private int startY;

    public Scaffold() {
        super("Scaffold", "Automatically places blocks under you", Category.WORLD);
        addSetting(tower);
        addSetting(extend);
        addSetting(keepY);
        addSetting(safeWalk);
    }

    @Override
    public void onEnable() {
        if (mc.field_1724 != null) {
            startY = (int) mc.field_1724.method_23318();
        }
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (keepY.getValue() && !mc.field_1724.method_31549().field_7479 && !mc.field_1690.field_1903.method_1434()) {
            // Adjust startY if we fall below it so we don't scaffold in the air above us
            if (mc.field_1724.method_23318() < startY) {
                startY = (int) mc.field_1724.method_23318();
            }
        } else {
            startY = (int) mc.field_1724.method_23318();
        }

        // Tower logic
        if (tower.getValue() && mc.field_1690.field_1903.method_1434() && mc.field_1724.method_18798().field_1352 == 0 && mc.field_1724.method_18798().field_1350 == 0) {
            mc.field_1724.method_18800(0, 0.42, 0);
        }

        int ext = extend.getValue().intValue();
        class_243 velocity = mc.field_1724.method_18798();
        class_243 forward = new class_243(velocity.field_1352, 0, velocity.field_1350).method_1029();
        if (velocity.field_1352 == 0 && velocity.field_1350 == 0) forward = class_243.field_1353;

        int blockSlot = getBlockSlot();
        if (blockSlot == -1) return;

        for (int i = 0; i <= ext; i++) {
            class_2338 targetPos = new class_2338(
                    (int) Math.floor(mc.field_1724.method_23317() + forward.field_1352 * i),
                    startY - 1,
                    (int) Math.floor(mc.field_1724.method_23321() + forward.field_1350 * i)
            );

            if (mc.field_1687.method_8320(targetPos).method_45474()) {
                int oldSlot = mc.field_1724.method_31548().field_7545;
                if (oldSlot != blockSlot) {
                    mc.field_1724.method_31548().field_7545 = blockSlot;
                    mc.method_1562().method_52787(new net.minecraft.class_2868(blockSlot));
                }

                placeBlock(targetPos);

                if (oldSlot != blockSlot) {
                    mc.field_1724.method_31548().field_7545 = oldSlot;
                    mc.method_1562().method_52787(new net.minecraft.class_2868(oldSlot));
                }
                // If we placed a block, don't place more in the same tick unless you want fast extend
                break;
            }
        }
    }

    private void placeBlock(class_2338 pos) {
        if (mc.field_1761 == null || mc.field_1724 == null) return;
        
        // Find a neighboring block to place against, since placing in mid-air doesn't always work on servers
        class_2350 placeDir = class_2350.field_11036;
        class_2338 placePos = pos;
        
        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(dir);
            if (!mc.field_1687.method_8320(neighbor).method_45474()) {
                placePos = neighbor;
                placeDir = dir.method_10153();
                break;
            }
        }

        class_3965 hitResult = new class_3965(class_243.method_24953(placePos).method_1019(class_243.method_24954(placeDir.method_10163()).method_1021(0.5)), placeDir, placePos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private int getBlockSlot() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1747) {
                if (((class_1747) stack.method_7909()).method_7711() != class_2246.field_10102 && ((class_1747) stack.method_7909()).method_7711() != class_2246.field_10255) {
                    return i;
                }
            }
        }
        return -1;
    }
    
    public boolean shouldSafeWalk() {
        return this.isEnabled() && safeWalk.getValue();
    }
}
