package com.acs.module.modules.world;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;
import fi.dy.masa.litematica.world.SchematicWorldHandler;
import fi.dy.masa.litematica.world.WorldSchematic;
import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3965;

public class Printer extends Module {

    private final NumberSetting range = new NumberSetting("Range", 4.0, 1.0, 6.0, 0.1);
    private final NumberSetting delay = new NumberSetting("Delay", 1.0, 0.0, 10.0, 1.0);
    private final NumberSetting blocksPerTick = new NumberSetting("Blocks/Tick", 1.0, 1.0, 10.0, 1.0);

    private int delayTimer = 0;

    public Printer() {
        super("Printer", "Automatically builds Litematica schematics", Category.WORLD);
        addSetting(range);
        addSetting(delay);
        addSetting(blocksPerTick);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1687 == null)
            return;

        if (delayTimer > 0) {
            delayTimer--;
            return;
        }

        try {
            WorldSchematic schematicWorld = SchematicWorldHandler.getSchematicWorld();
            if (schematicWorld == null)
                return;

            int r = range.getValue().intValue();
            class_2338 playerPos = mc.field_1724.method_24515();
            int placedThisTick = 0;
            int maxBlocks = blocksPerTick.getValue().intValue();

            for (int x = -r; x <= r; x++) {
                for (int y = -r; y <= r; y++) {
                    for (int z = -r; z <= r; z++) {
                        if (placedThisTick >= maxBlocks) {
                            if (delay.getValue().intValue() > 0) {
                                delayTimer = delay.getValue().intValue();
                            }
                            return;
                        }

                        class_2338 pos = playerPos.method_10069(x, y, z);

                        if (mc.field_1724.method_5707(class_243.method_24953(pos)) > range.getValue() * range.getValue()) {
                            continue;
                        }

                        class_2680 expectedState = schematicWorld.method_8320(pos);
                        if (expectedState == null || expectedState.method_26215())
                            continue;

                        class_2680 currentState = mc.field_1687.method_8320(pos);
                        if (currentState.method_26204() == expectedState.method_26204())
                            continue;
                        if (!currentState.method_45474())
                            continue;

                        int slot = findBlockInHotbar(expectedState.method_26204());
                        if (slot != -1) {
                            placeBlock(pos, slot);
                            placedThisTick++;
                        }
                    }
                }
            }

            if (placedThisTick > 0 && delay.getValue().intValue() > 0) {
                delayTimer = delay.getValue().intValue();
            }
        } catch (NoClassDefFoundError | Exception e) {
            // Litematica is not installed or error occurred
        }
    }

    private void placeBlock(class_2338 pos, int slot) {
        if (mc.field_1761 == null || mc.field_1724 == null)
            return;

        int oldSlot = mc.field_1724.method_31548().field_7545;
        if (oldSlot != slot) {
            mc.field_1724.method_31548().field_7545 = slot;
            if (mc.method_1562() != null) {
                mc.method_1562()
                        .method_52787(new net.minecraft.class_2868(slot));
            }
        }

        class_2350 placeDir = class_2350.field_11036;
        class_2338 placePos = pos;

        for (class_2350 dir : class_2350.values()) {
            class_2338 neighbor = pos.method_10093(dir);
            if (!mc.field_1687.method_8320(neighbor).method_45474()) {
                placePos = neighbor;
                placeDir = dir.method_10153();
                break;
            }
        }

        class_3965 hitResult = new class_3965(
                class_243.method_24953(placePos).method_1019(class_243.method_24954(placeDir.method_10163()).method_1021(0.5)), placeDir, placePos, false);
        mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
        mc.field_1724.method_6104(class_1268.field_5808);

        if (oldSlot != slot) {
            mc.field_1724.method_31548().field_7545 = oldSlot;
            if (mc.method_1562() != null) {
                mc.method_1562()
                        .method_52787(new net.minecraft.class_2868(oldSlot));
            }
        }
    }

    private int findBlockInHotbar(class_2248 block) {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() instanceof class_1747) {
                if (((class_1747) stack.method_7909()).method_7711() == block) {
                    return i;
                }
            }
        }
        return -1;
    }
}
