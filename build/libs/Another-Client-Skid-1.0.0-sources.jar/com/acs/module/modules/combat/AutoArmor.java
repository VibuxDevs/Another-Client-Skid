package com.acs.module.modules.combat;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.class_1713;
import net.minecraft.class_1738;
import net.minecraft.class_1799;

public class AutoArmor extends Module {

    public AutoArmor() {
        super("AutoArmor", "Automatically equips best armor", Category.COMBAT);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        if (mc.field_1724.field_7512 == mc.field_1724.field_7498) {
            for (int type = 0; type < 4; type++) {
                int bestArmorSlot = getBestArmorSlot(type);
                if (bestArmorSlot != -1) {
                    equipArmor(bestArmorSlot);
                }
            }
        }
    }

    private int getBestArmorSlot(int type) {
        int bestSlot = -1;
        int bestProtection = 0;

        // Currently equipped armor
        class_1799 equipped = mc.field_1724.method_31548().method_7372(type);
        if (equipped.method_7909() instanceof class_1738) {
            bestProtection = ((class_1738) equipped.method_7909()).method_7687();
        }

        for (int i = 9; i < 45; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i >= 36 ? i - 36 : i);
            if (stack.method_7909() instanceof class_1738 armor) {
                // Check if it's the correct slot type (helmet, chestplate, etc)
                if (armor.method_48398().method_48399().method_5927() == type) {
                    if (armor.method_7687() > bestProtection) {
                        bestProtection = armor.method_7687();
                        bestSlot = i;
                    }
                }
            }
        }
        return bestSlot;
    }

    private void equipArmor(int slot) {
        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7794, mc.field_1724);
    }
}
