package com.acs.module.modules.combat;

import com.acs.module.Category;
import com.acs.module.Module;
import com.acs.settings.NumberSetting;
import net.minecraft.class_1713;
import net.minecraft.class_1802;

public class AutoTotem extends Module {
    
    private final NumberSetting healthThreshold = new NumberSetting("Health", 16.0, 1.0, 36.0, 1.0);

    public AutoTotem() {
        super("AutoTotem", "Automatically places a totem in your offhand", Category.COMBAT);
        addSetting(healthThreshold);
    }

    @Override
    public void onTick() {
        if (mc.field_1724 == null || mc.field_1761 == null) return;
        
        if (mc.field_1724.method_6079().method_7909() == class_1802.field_8288) return;
        
        float health = mc.field_1724.method_6032() + mc.field_1724.method_6067();
        
        if (health <= healthThreshold.getValue()) {
            int totemSlot = getTotemSlot();
            if (totemSlot != -1) {
                moveToOffhand(totemSlot);
            }
        }
    }
    
    private int getTotemSlot() {
        for (int i = 9; i < 45; i++) {
            if (mc.field_1724.method_31548().method_5438(i >= 36 ? i - 36 : i).method_7909() == class_1802.field_8288) {
                return i;
            }
        }
        return -1;
    }
    
    private void moveToOffhand(int slot) {
        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7790, mc.field_1724);
        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 45, 0, class_1713.field_7790, mc.field_1724); // 45 is offhand slot in player inventory
        mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slot, 0, class_1713.field_7790, mc.field_1724);
    }
}
