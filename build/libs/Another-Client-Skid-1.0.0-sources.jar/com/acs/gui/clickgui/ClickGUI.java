package com.acs.gui.clickgui;

import com.acs.gui.hud.HudManager;
import com.acs.gui.hud.HudComponent;
import com.acs.module.Category;
import com.acs.manager.FriendManager;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_437;

public class ClickGUI extends class_437 {
    public static final ClickGUI INSTANCE = new ClickGUI();
    private final List<Frame> frames = new ArrayList<>();
    private final ParticleSystem particleSystem = new ParticleSystem(100);
    private  final class_310 mc = class_310.method_1551();
    private int currentPage = 0;
    private String searchText = "";
    private boolean searchFocused = false;

    // Friends page state
    private String friendInput = "";
    private boolean friendInputFocused = false;
    private String friendStatus = "";


public ClickGUI() {
    super(class_2561.method_43470("ACS Client"));
    frames.clear();
    int x = mc.method_22683().method_4486();
        frames.add(new Frame(Category.RENDER,  1 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.PLAYER,  2 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.COMBAT,  3 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.MOVEMENT,4 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.EXPLOITS,5 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.MISC,    6 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.WORLD,   7 * x/8-100,  35, 100, 14));
        frames.add(new Frame(Category.CLIENT,  8 * x/8-100,  35, 100, 14));
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, field_22789, field_22790, 0xA0000000);
        particleSystem.render(context, field_22789, field_22790);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        // Header bar
        context.method_25294(0, 0, field_22789, 25, 0xFF000000);
        context.method_25296(0, 24, field_22789, 25, 0xFFFF0000, 0x00FF0000);

        // Search bar — highlight border when focused
        int searchBorder = searchFocused ? 0xFFFF0000 : 0xFF333333;
        context.method_25294(4, 4, 156, 21, searchBorder);
        context.method_25294(5, 5, 155, 20, 0xFF111111);
        context.method_25294(5, 5, 7, 20, 0xFFFF0000);
        String displaySearch = searchText.isEmpty() ? (searchFocused ? "_" : "Search...") : searchText + (searchFocused ? "_" : "");
        context.method_25303(this.field_22793, displaySearch, 12, 8, searchText.isEmpty() && !searchFocused ? 0xFF555555 : 0xFFFFFFFF);

        int centerX = this.field_22789 / 2;
        renderTab(context, "Modules",  centerX - 80, 5, currentPage == 0);
        renderTab(context, "UI",       centerX - 20, 5, currentPage == 1);
        renderTab(context, "Friends",  centerX + 30, 5, currentPage == 2);
        renderTab(context, "Settings", centerX + 80, 5, currentPage == 3);

        if (currentPage == 0) {
            if (ModuleButton.activeSlider != null) {
                if (org.lwjgl.glfw.GLFW.glfwGetMouseButton(mc.method_22683().method_4490(), org.lwjgl.glfw.GLFW.GLFW_MOUSE_BUTTON_LEFT) == org.lwjgl.glfw.GLFW.GLFW_RELEASE) {
                    ModuleButton.activeSlider = null;
                } else {
                    com.acs.settings.NumberSetting ns = ModuleButton.activeSlider;
                    double percent = (mouseX - ModuleButton.sliderX) / (double) ModuleButton.sliderWidth;
                    if (percent < 0) percent = 0;
                    if (percent > 1) percent = 1;
                    double val = ns.getMin() + percent * (ns.getMax() - ns.getMin());
                    val = Math.round(val / ns.getIncrement()) * ns.getIncrement();
                    if (val < ns.getMin()) val = ns.getMin();
                    if (val > ns.getMax()) val = ns.getMax();
                    ns.setValue(val);
                }
            }
            for (Frame frame : frames) {
                frame.render(context, mouseX, mouseY, delta, searchText);
            }
        } else if (currentPage == 1) {
            renderUIPage(context, mouseX, mouseY);
        } else if (currentPage == 2) {
            renderFriendsPage(context, mouseX, mouseY);
        } else if (currentPage == 3) {
            renderSettingsPage(context, mouseX, mouseY);
        }
    }

    private void renderUIPage(class_332 context, int mouseX, int mouseY) {
        int centerX = this.field_22789 / 2;
        context.method_25300(this.field_22793, "§cHUD Components", centerX, 35, 0xFFFFFFFF);
        context.method_25294(centerX - 100, 44, centerX + 100, 45, 0xFFFF0000);

        int y = 55;
        for (HudComponent component : HudManager.INSTANCE.getComponents()) {
            boolean hovered = mouseX >= centerX - 100 && mouseX <= centerX + 100 && mouseY >= y && mouseY <= y + 14;
            context.method_25294(centerX - 101, y - 1, centerX + 101, y + 15, 0xFF000000);
            context.method_25294(centerX - 100, y, centerX + 100, y + 14, hovered ? 0xFF222222 : 0xFF111111);
            context.method_25294(centerX - 100, y, centerX - 98, y + 14, component.isEnabled() ? 0xFFFF0000 : 0xFF444444);
            context.method_25303(this.field_22793, component.getName(), centerX - 93, y + 2, component.isEnabled() ? 0xFFFFFFFF : 0xFF888888);
            context.method_25303(this.field_22793, component.isEnabled() ? "ON" : "OFF", centerX + 85 - this.field_22793.method_1727(component.isEnabled() ? "ON" : "OFF"), y + 2, component.isEnabled() ? 0xFF00FF00 : 0xFFFF4444);
            y += 17;
        }
    }

    private void renderFriendsPage(class_332 context, int mouseX, int mouseY) {
        int centerX = this.field_22789 / 2;
        context.method_25300(this.field_22793, "§cFriends List", centerX, 35, 0xFFFFFFFF);
        context.method_25294(centerX - 100, 44, centerX + 100, 45, 0xFFFF0000);

        // Friend input box
        int inputBorder = friendInputFocused ? 0xFFFF0000 : 0xFF333333;
        context.method_25294(centerX - 101, 51, centerX + 51, 66, inputBorder);
        context.method_25294(centerX - 100, 52, centerX + 50, 65, 0xFF111111);
        String dispInput = friendInput + (friendInputFocused ? "_" : "");
        context.method_25303(this.field_22793, dispInput.isEmpty() && !friendInputFocused ? "Player name..." : dispInput, centerX - 95, 56, friendInput.isEmpty() && !friendInputFocused ? 0xFF555555 : 0xFFFFFFFF);

        // Add/Remove buttons
        boolean addHover = mouseX >= centerX + 55 && mouseX <= centerX + 100 && mouseY >= 51 && mouseY <= 66;
        context.method_25294(centerX + 54, 51, centerX + 101, 66, 0xFF000000);
        context.method_25294(centerX + 55, 52, centerX + 100, 65, addHover ? 0xFF1a4d1a : 0xFF112211);
        context.method_25300(this.field_22793, "Add", centerX + 77, 56, 0xFF00FF00);

        if (!friendStatus.isEmpty()) {
            context.method_25300(this.field_22793, friendStatus, centerX, 70, 0xFFFFAA00);
        }

        int y = 80;
        for (String friend : FriendManager.INSTANCE.getFriends()) {
            boolean hovered = mouseX >= centerX - 100 && mouseX <= centerX + 100 && mouseY >= y && mouseY <= y + 14;
            context.method_25294(centerX - 101, y - 1, centerX + 101, y + 15, 0xFF000000);
            context.method_25294(centerX - 100, y, centerX + 100, y + 14, hovered ? 0xFF222222 : 0xFF111111);
            context.method_25294(centerX - 100, y, centerX - 98, y + 14, 0xFF00CC00);
            context.method_25303(this.field_22793, friend, centerX - 93, y + 2, 0xFF00FF00);
            context.method_25303(this.field_22793, "✗", centerX + 87, y + 2, 0xFFFF4444);
            y += 17;
        }
    }

    private void renderSettingsPage(class_332 context, int mouseX, int mouseY) {
        int centerX = this.field_22789 / 2;
        context.method_25300(this.field_22793, "§cGlobal Settings", centerX, 35, 0xFFFFFFFF);
        context.method_25294(centerX - 100, 44, centerX + 100, 45, 0xFFFF0000);
        context.method_25300(this.field_22793, "§7More settings coming soon...", centerX, 60, 0xFF888888);
    }

    private void renderTab(class_332 context, String text, int x, int y, boolean active) {
        int bgColor = active ? 0xFFFF0000 : 0xFF111111;
        context.method_25294(x - 1, y - 1, x + 51, y + 16, 0xFF000000);
        context.method_25294(x, y, x + 50, y + 15, bgColor);
        if (active) context.method_25294(x, y + 14, x + 50, y + 15, 0xFFFFFFFF);
        context.method_25303(this.field_22793, text, x + (50 - this.field_22793.method_1727(text)) / 2, y + 3, active ? 0xFFFFFFFF : 0xFFAAAAAA);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        int centerX = this.field_22789 / 2;

        // Tab clicks
        if (mouseY >= 5 && mouseY <= 20) {
            if (mouseX >= centerX - 80 && mouseX <= centerX - 30) { currentPage = 0; return true; }
            if (mouseX >= centerX - 20 && mouseX <= centerX + 30) { currentPage = 1; return true; }
            if (mouseX >= centerX + 30 && mouseX <= centerX + 80) { currentPage = 2; return true; }
            if (mouseX >= centerX + 80 && mouseX <= centerX + 130){ currentPage = 3; return true; }
        }

        // Search bar focus
        if (mouseX >= 5 && mouseX <= 155 && mouseY >= 5 && mouseY <= 20) {
            searchFocused = true;
            friendInputFocused = false;
            return true;
        } else {
            searchFocused = false;
        }

        if (currentPage == 0) {
            for (Frame frame : frames) {
                if (frame.mouseClicked(mouseX, mouseY, button)) return true;
            }
        } else if (currentPage == 1) {
            // HUD component toggles
            int y = 55;
            for (HudComponent component : HudManager.INSTANCE.getComponents()) {
                if (mouseX >= centerX - 100 && mouseX <= centerX + 100 && mouseY >= y && mouseY <= y + 14) {
                    component.setEnabled(!component.isEnabled());
                    return true;
                }
                y += 17;
            }
        } else if (currentPage == 2) {
            // Add friend button
            if (mouseX >= centerX + 55 && mouseX <= centerX + 100 && mouseY >= 51 && mouseY <= 66) {
                if (!friendInput.isEmpty()) {
                    FriendManager.INSTANCE.addFriend(friendInput);
                    friendStatus = "Added " + friendInput + "!";
                    friendInput = "";
                }
                return true;
            }
            // Remove friend (X button)
            int y = 80;
            for (String friend : new ArrayList<>(FriendManager.INSTANCE.getFriends())) {
                if (mouseX >= centerX + 87 && mouseX <= centerX + 100 && mouseY >= y && mouseY <= y + 14) {
                    FriendManager.INSTANCE.removeFriend(friend);
                    friendStatus = "Removed " + friend;
                    return true;
                }
                y += 17;
            }
            // Friend input focus
            if (mouseX >= centerX - 100 && mouseX <= centerX + 50 && mouseY >= 51 && mouseY <= 66) {
                friendInputFocused = true;
                searchFocused = false;
                return true;
            } else {
                friendInputFocused = false;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        for (Frame frame : frames) frame.mouseReleased(mouseX, mouseY, button);
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        if (searchFocused) {
            searchText += chr;
            return true;
        }
        if (friendInputFocused) {
            friendInput += chr;
            return true;
        }
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // Route to frames for bind listening first
        if (currentPage == 0) {
            for (Frame frame : frames) {
                if (frame.keyPressed(keyCode)) return true;
            }
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE) {
            if (searchFocused && !searchText.isEmpty()) {
                searchText = searchText.substring(0, searchText.length() - 1);
                return true;
            }
            if (friendInputFocused && !friendInput.isEmpty()) {
                friendInput = friendInput.substring(0, friendInput.length() - 1);
                return true;
            }
        }
        if (keyCode == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) {
            searchFocused = false;
            friendInputFocused = false;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
