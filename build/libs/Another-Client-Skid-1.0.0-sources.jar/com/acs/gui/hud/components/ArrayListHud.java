package com.acs.gui.hud.components;

import com.acs.gui.hud.HudComponent;
import com.acs.module.Module;
import com.acs.module.ModuleManager;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_332;

public class ArrayListHud extends HudComponent {
    public ArrayListHud(int x, int y) {
        super("ArrayList", x, y);
    }

    @Override
    public void render(class_332 context, float delta) {
        List<Module> enabledModules = ModuleManager.INSTANCE.getModules().stream()
                .filter(Module::isEnabled)
                .sorted(Comparator.comparingInt(m -> -mc.field_1772.method_1727(m.getName())))
                .collect(Collectors.toList());

        int offset = 0;
        int screenWidth = mc.method_22683().method_4486();

        for (Module module : enabledModules) {
            String name = module.getName();
            int width = mc.field_1772.method_1727(name);
            // Render on the right side by default for OyVey style
            context.method_25303(mc.field_1772, name, screenWidth - width - 5, getY() + offset, 0xFFFF0000);
            offset += mc.field_1772.field_2000 + 1;
        }
    }
}
