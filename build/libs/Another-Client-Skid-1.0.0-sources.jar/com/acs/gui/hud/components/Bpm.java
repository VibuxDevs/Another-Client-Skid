package com.acs.gui.hud.components;

import com.acs.gui.hud.HudComponent;
import net.minecraft.class_332;

public class Bpm extends HudComponent {
    public Bpm(int x, int y) {
        super("Bpm", x, y);
    }

    @Override
    public void render(class_332 context, float delta) {
        double bpm = 0;
        if (mc.field_1724 != null) {
            double diffX = mc.field_1724.method_23317() - mc.field_1724.field_6014;
            double diffZ = mc.field_1724.method_23321() - mc.field_1724.field_5969;
            double speedPerTick = Math.sqrt(diffX * diffX + diffZ * diffZ);
            bpm = speedPerTick * 20.0 * 60.0;
        }

        String text = String.format("\u00A77BPM: \u00A7a%.1f", bpm);
        context.method_25303(mc.field_1772, text, getX(), getY(), 0xFFFFFFFF);
    }
}
