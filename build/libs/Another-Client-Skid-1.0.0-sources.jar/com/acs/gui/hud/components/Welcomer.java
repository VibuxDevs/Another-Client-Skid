package com.acs.gui.hud.components;

import com.acs.gui.hud.HudComponent;
import net.minecraft.class_332;

public class Welcomer extends HudComponent {
    public Welcomer(int x, int y) {
        super("Welcomer", x, y);
    }

    @Override
    public void render(class_332 context, float delta) {
        String text = "Welcome back, " + mc.method_1548().method_1676() + "!";
        int screenWidth = mc.method_22683().method_4486();
        context.method_25300(mc.field_1772, text, screenWidth / 2, getY(), 0xFFFF0000);
    }
}
