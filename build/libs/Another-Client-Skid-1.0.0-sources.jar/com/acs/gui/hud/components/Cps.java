package com.acs.gui.hud.components;

import com.acs.gui.hud.HudComponent;
import com.acs.module.ModuleManager;
import com.acs.module.modules.pvp.CrystalAura;
import net.minecraft.class_332;

public class Cps extends HudComponent {
    public Cps(int x, int y) {
        super("Cps", x, y);
    }

    @Override
    public void render(class_332 context, float delta) {
        CrystalAura crystalAura = (CrystalAura) ModuleManager.INSTANCE.getModuleByName("CrystalAura");

        String text;
        if (crystalAura != null && crystalAura.isEnabled()) {
            int cps = (int) crystalAura.getCurrentCps();
            text = "\u00A77CPS: \u00A7c" + cps;
        } else {
            text = "\u00A77CPS \u00A7f: \u00A7cdisabled";
        }

        context.method_25303(mc.field_1772, text, getX(), getY(), 0xFFFFFFFF);
    }
}
