package com.acs.gui;

import com.acs.mixin.MinecraftClientAccessor;
import com.acs.utils.MicrosoftAuth;
import com.acs.utils.AltManager;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_2561;
import net.minecraft.class_320;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class AltSwitcherScreen extends class_437 {
    private final class_437 parent;
    private class_342 usernameField;
    private String status = "Idle";
    private Thread pollThread;

    public AltSwitcherScreen(class_437 parent) {
        super(class_2561.method_43470("Alt Switcher"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        AltManager.load();
        int centerX = this.field_22789 / 2;
        int centerY = this.field_22790 / 2;

        // Add username input field
        usernameField = new class_342(
            this.field_22793,
            centerX - 150,
            centerY - 40,
            140,
            20,
            class_2561.method_43470("Username")
        );
        usernameField.method_1880(16);
        usernameField.method_1852("");
        this.method_25429(usernameField);

        // Add offline login button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Login (Offline)"), button -> {
            stopPolling();
            String username = usernameField.method_1882().trim();
            if (!username.isEmpty()) {
                try {
                    UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
                    class_320 session = new class_320(
                        username,
                        uuid,
                        "",
                        Optional.empty(),
                        Optional.empty(),
                        class_320.class_321.field_1988
                    );
                    ((MinecraftClientAccessor) field_22787).setSession(session);
                    status = "Logged in as: " + username;
                    AltManager.addAlt(false, username, "", "");
                    this.method_41843();
                } catch (Exception e) {
                    status = "Error: " + e.getMessage();
                }
            } else {
                status = "Username cannot be empty!";
            }
        }).method_46434(centerX - 150, centerY, 140, 20).method_46431());

        // Add Microsoft login button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Login (Microsoft)"), button -> {
            stopPolling();
            status = "Requesting device code...";
            new Thread(() -> {
                try {
                    MicrosoftAuth.DeviceCodeInfo info = MicrosoftAuth.getDeviceCode();
                    status = "Code: " + info.userCode + " (copied). Link: " + info.verificationUri;
                    
                    // Copy code to clipboard on client thread
                    field_22787.execute(() -> {
                        field_22787.field_1774.method_1455(info.userCode);
                    });

                    // Start background polling
                    pollThread = new Thread(() -> {
                        while (pollThread != null && !Thread.currentThread().isInterrupted()) {
                            MicrosoftAuth.LoginResult result = MicrosoftAuth.pollToken(info.deviceCode);
                            if (result.error == null) {
                                try {
                                    UUID uuid = parseDashlessUuid(result.uuid);
                                    class_320 session = new class_320(
                                        result.username,
                                        uuid,
                                        result.token,
                                        Optional.empty(),
                                        Optional.empty(),
                                        class_320.class_321.field_1988
                                    );
                                    field_22787.execute(() -> {
                                        ((MinecraftClientAccessor) field_22787).setSession(session);
                                    });
                                    status = "Logged in as: " + result.username;
                                    AltManager.addAlt(true, result.username, result.uuid, result.refreshToken);
                                    field_22787.execute(this::method_41843);
                                } catch (Exception e) {
                                    status = "Session error: " + e.getMessage();
                                }
                                break;
                            } else if (!"PENDING".equals(result.error)) {
                                status = "Error: " + result.error;
                                break;
                            }

                            try {
                                Thread.sleep(info.interval * 1000L);
                            } catch (InterruptedException e) {
                                break;
                            }
                        }
                    });
                    pollThread.start();

                } catch (Exception e) {
                    status = "Failed to start MS Auth: " + e.getMessage();
                }
            }).start();
        }).method_46434(centerX - 150, centerY + 25, 140, 20).method_46431());

        // Add back button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Back"), button -> {
            stopPolling();
            field_22787.method_1507(parent);
        }).method_46434(centerX - 150, centerY + 50, 140, 20).method_46431());

        // Draw the saved alts list
        List<AltManager.AltEntry> entries = AltManager.getAlts();
        int altY = centerY - 40;
        for (int i = 0; i < Math.min(entries.size(), 5); i++) {
            AltManager.AltEntry alt = entries.get(i);
            // Login button for this alt
            String displayName = alt.username + " (" + (alt.isMicrosoft ? "MS" : "Off") + ")";
            this.method_37063(class_4185.method_46430(class_2561.method_43470(displayName), btn -> {
                stopPolling();
                if (alt.isMicrosoft) {
                    status = "Refreshing " + alt.username + "...";
                    new Thread(() -> {
                        MicrosoftAuth.LoginResult res = MicrosoftAuth.loginWithRefreshToken(alt.refreshToken);
                        if (res.error == null) {
                            try {
                                UUID uuid = parseDashlessUuid(res.uuid);
                                class_320 session = new class_320(
                                    res.username,
                                    uuid,
                                    res.token,
                                    Optional.empty(),
                                    Optional.empty(),
                                    class_320.class_321.field_1988
                                );
                                field_22787.execute(() -> {
                                    ((MinecraftClientAccessor) field_22787).setSession(session);
                                });
                                status = "Logged in as: " + res.username;
                                AltManager.addAlt(true, res.username, res.uuid, res.refreshToken);
                                field_22787.execute(this::method_41843);
                            } catch (Exception e) {
                                status = "Session error: " + e.getMessage();
                            }
                        } else {
                            status = "Failed: " + res.error;
                        }
                    }).start();
                } else {
                    // Offline login
                    try {
                        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + alt.username).getBytes(StandardCharsets.UTF_8));
                        class_320 session = new class_320(
                            alt.username,
                            uuid,
                            "",
                            Optional.empty(),
                            Optional.empty(),
                            class_320.class_321.field_1988
                        );
                        ((MinecraftClientAccessor) field_22787).setSession(session);
                        status = "Logged in as: " + alt.username;
                    } catch (Exception e) {
                        status = "Error: " + e.getMessage();
                    }
                }
            }).method_46434(centerX + 10, altY + i * 22, 135, 20).method_46431());

            // Delete button for this alt
            this.method_37063(class_4185.method_46430(class_2561.method_43470("X"), btn -> {
                AltManager.removeAlt(alt.username);
                this.method_41843();
            }).method_46434(centerX + 150, altY + i * 22, 20, 20).method_46431());
        }
    }

    private void stopPolling() {
        if (pollThread != null) {
            pollThread.interrupt();
            pollThread = null;
        }
    }

    private UUID parseDashlessUuid(String dashless) {
        if (dashless == null || dashless.length() != 32) {
            return UUID.randomUUID();
        }
        String withDashes = dashless.substring(0, 8) + "-" +
                             dashless.substring(8, 12) + "-" +
                             dashless.substring(12, 16) + "-" +
                             dashless.substring(16, 20) + "-" +
                             dashless.substring(20);
        return UUID.fromString(withDashes);
    }

    @Override
    public void method_25419() {
        stopPolling();
        super.method_25419();
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        super.method_25394(context, mouseX, mouseY, delta);

        // Render title
        context.method_25300(this.field_22793, "Alt Switcher", this.field_22789 / 2, 20, 0xFFFF0000);

        // Render current session info
        String currentSession = "Current User: " + field_22787.method_1548().method_1676() + " (" + field_22787.method_1548().method_44717() + ")";
        context.method_25300(this.field_22793, currentSession, this.field_22789 / 2, 50, 0xFFAAAAAA);

        // Render status
        context.method_25300(this.field_22793, "Status: " + status, this.field_22789 / 2, 70, 0xFFFF5555);

        // Render labels
        context.method_25303(this.field_22793, "New Username:", this.field_22789 / 2 - 150, this.field_22790 / 2 - 52, 0xFFFFFFFF);
        context.method_25303(this.field_22793, "Saved Accounts:", this.field_22789 / 2 + 10, this.field_22790 / 2 - 52, 0xFFFFFFFF);

        if (AltManager.getAlts().isEmpty()) {
            context.method_25303(this.field_22793, "No saved accounts", this.field_22789 / 2 + 10, this.field_22790 / 2 - 35, 0xFF888888);
        }

        usernameField.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        usernameField.method_25402(mouseX, mouseY, button);
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (usernameField.method_25404(keyCode, scanCode, modifiers)) {
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean method_25400(char chr, int modifiers) {
        if (usernameField.method_25400(chr, modifiers)) {
            return true;
        }
        return super.method_25400(chr, modifiers);
    }
}
