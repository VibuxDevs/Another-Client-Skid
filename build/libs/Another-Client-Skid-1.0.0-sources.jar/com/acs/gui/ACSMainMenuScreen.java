package com.acs.gui;

import com.acs.gui.clickgui.ParticleSystem;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;

public class ACSMainMenuScreen extends class_437 {
    private static final String[] SPLASHES = {
        "ACS Client on Top!",
        "Another Client Skid!",
        "NoCap!",
        "Skidded with pride!",
        "Fully automated!",
        "Outsmarting anticheats!",
        "Now with 100% more skid!",
        "Premium utility mod!",
        "Hacker mode activated!",
        "Coordinate exploits included!",
        "Cracking seeds like walnuts!",
        "Play 6p9t.org :3",
        "Still waiting for my $20 :(",
        "Still waiting for jbae to add stuff to this client :("
    };

    private final ParticleSystem particleSystem = new ParticleSystem(150);
    private final String currentSplash;

    public ACSMainMenuScreen() {
        super(class_2561.method_43470("ACS Main Menu"));
        this.currentSplash = SPLASHES[new java.util.Random().nextInt(SPLASHES.length)];
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Overriding to prevent vanilla dirt/blur background from rendering on top.
        // Draw our custom background gradient and particles.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF050505);
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0x30FF0000, 0x05000000);
        particleSystem.render(context, this.field_22789, this.field_22790);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Render the background first (calls renderBackground above)
        super.method_25394(context, mouseX, mouseY, delta);

        // Center card (Glassmorphic panel)
        int cardWidth = 200;
        int cardHeight = 270;
        int startX = (this.field_22789 - cardWidth) / 2;
        int startY = (this.field_22790 - cardHeight) / 2;

        // Draw card background (semi-transparent dark)
        context.method_25294(startX - 1, startY - 1, startX + cardWidth + 1, startY + cardHeight + 1, 0xFF440000); // glowing border
        context.method_25294(startX, startY, startX + cardWidth, startY + cardHeight, 0xE0101010);

        // Draw logo
        String logoTitle = "ACS CLIENT";
        String logoSub = "Another Client Skid";
        context.method_25300(this.field_22793, logoTitle, this.field_22789 / 2, startY + 16, 0xFFFF0000);
        context.method_25300(this.field_22793, logoSub, this.field_22789 / 2, startY + 28, 0xFF888888);

        // Draw custom yellow splash text
        double scale = 1.0 + 0.08 * Math.sin(System.currentTimeMillis() / 200.0);
        context.method_51448().method_22903();
        context.method_51448().method_46416(this.field_22789 / 2.0f + 62.0f, startY + 22.0f, 0.0f);
        context.method_51448().method_22907(net.minecraft.class_7833.field_40718.rotation(-0.25f));
        context.method_51448().method_22905((float) scale, (float) scale, 1.0f);
        context.method_25300(this.field_22793, this.currentSplash, 0, 0, 0xFFFFCC00);
        context.method_51448().method_22909();

        // Top-left custom yellow text watermark
        context.method_25303(this.field_22793, "ACS | 1.0.0", 6, 6, 0xFFFFDD00);

        // Draw line separator
        context.method_25294(startX + 20, startY + 44, startX + cardWidth - 20, startY + 45, 0x44FF0000);

        // Render custom buttons
        int buttonY = startY + 60;
        int buttonHeight = 24;
        int buttonSpacing = 8;

        drawCustomButton(context, "Singleplayer", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Multiplayer", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Alt Switcher", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Options", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Quit", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);

        // Bottom info
        context.method_25303(this.field_22793, "ACS Client v1.0.0", 5, this.field_22790 - 12, 0xFF555555);
        if (field_22787 != null && field_22787.method_1548() != null) {
            String username = field_22787.method_1548().method_1676();
            context.method_25303(this.field_22793, "Logged in as: " + username, this.field_22789 - this.field_22793.method_1727("Logged in as: " + username) - 5, this.field_22790 - 12, 0xFF555555);
        }
    }

    private void drawCustomButton(class_332 context, String label, int x, int y, int w, int h, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        int borderCol = hovered ? 0xFFFF0000 : 0xFF222222;
        int bgCol = hovered ? 0xFF1C0505 : 0xFF0D0D0D;
        int textCol = hovered ? 0xFFFFFFFF : 0xFFAAAAAA;

        context.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, borderCol);
        context.method_25294(x, y, x + w, y + h, bgCol);
        context.method_25300(this.field_22793, label, x + w / 2, y + (h - 8) / 2, textCol);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && field_22787 != null) {
            int cardWidth = 200;
            int cardHeight = 270;
            int startX = (this.field_22789 - cardWidth) / 2;
            int startY = (this.field_22790 - cardHeight) / 2;

            int buttonY = startY + 60;
            int buttonHeight = 24;
            int buttonSpacing = 8;
            int btnW = cardWidth - 30;

            // Singleplayer
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new class_526(this));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Multiplayer
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new class_500(this));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Alt Switcher
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new AltSwitcherScreen(this));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Options
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new class_429(this, field_22787.field_1690));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Quit
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1592();
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
