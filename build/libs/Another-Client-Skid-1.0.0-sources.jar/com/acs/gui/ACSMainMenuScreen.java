package com.acs.gui;

import com.acs.gui.clickgui.ParticleSystem;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;

public class ACSMainMenuScreen extends class_437 {
    private final ParticleSystem particleSystem = new ParticleSystem(150);

    public ACSMainMenuScreen() {
        super(class_2561.method_43470("ACS Main Menu"));
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        // Overriding to prevent vanilla dirt/blur background from rendering on top.
        // Draw our custom background gradient and particles.
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xFF050505);
        context.method_25296(0, 0, this.field_22789, this.field_22790, 0x30FF0000, 0x05000000);
        particleSystem.render(context, this.field_22789, this.field_22790);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        // Render the background first (calls renderBackground above)
        super.method_25394(context, mouseX, mouseY, delta);

        // Center card (Glassmorphic panel)
        int cardWidth = 200;
        int cardHeight = 240;
        int startX = (this.field_22789 - cardWidth) / 2;
        int startY = (this.field_22790 - cardHeight) / 2;

        // Draw card background (semi-transparent dark)
        context.method_25294(startX - 1, startY - 1, startX + cardWidth + 1, startY + cardHeight + 1, 0xFF440000); // glowing border
        context.method_25294(startX, startY, startX + cardWidth, startY + cardHeight, 0xE0101010);

        // Draw logo
        String logoTitle = "ACS CLIENT";
        String logoSub = "Another Client Skid";
        context.method_25300(this.field_22793, logoTitle, this.field_22789 / 2, startY + 20, 0xFFFF0000);
        context.method_25300(this.field_22793, logoSub, this.field_22789 / 2, startY + 32, 0xFF888888);

        // Draw line separator
        context.method_25294(startX + 20, startY + 48, startX + cardWidth - 20, startY + 49, 0x44FF0000);

        // Render custom buttons
        int buttonY = startY + 65;
        int buttonHeight = 24;
        int buttonSpacing = 8;

        drawCustomButton(context, "Singleplayer", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Multiplayer", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Options", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);
        buttonY += buttonHeight + buttonSpacing;

        drawCustomButton(context, "Quit", startX + 15, buttonY, cardWidth - 30, buttonHeight, mouseX, mouseY);

        // Bottom info
        context.method_25303(this.field_22793, "ACS Client v1.0.0", 5, this.field_22790 - 12, 0xFF555555);
        if (field_22787 != null && field_22787.method_1548() != null) {
            String username = field_22787.method_1548().method_1676();
            context.method_25303(this.field_22793, "Logged in as: " + username, this.field_22789 - this.field_22793.method_1727("Logged in as: " + username) - 5, this.field_22790 - 12, 0xFF555555);
        }
    }

    private void drawCustomButton(class_332 context, String label, int x, int y, int w, int h, int mouseX, int mouseY) {
        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
        int borderCol = hovered ? 0xFFFF0000 : 0xFF222222;
        int bgCol = hovered ? 0xFF1C0505 : 0xFF0D0D0D;
        int textCol = hovered ? 0xFFFFFFFF : 0xFFAAAAAA;

        context.method_25294(x - 1, y - 1, x + w + 1, y + h + 1, borderCol);
        context.method_25294(x, y, x + w, y + h, bgCol);
        context.method_25300(this.field_22793, label, x + w / 2, y + (h - 8) / 2, textCol);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        if (button == 0 && field_22787 != null) {
            int cardWidth = 200;
            int cardHeight = 240;
            int startX = (this.field_22789 - cardWidth) / 2;
            int startY = (this.field_22790 - cardHeight) / 2;

            int buttonY = startY + 65;
            int buttonHeight = 24;
            int buttonSpacing = 8;
            int btnW = cardWidth - 30;

            // Singleplayer
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new class_526(this));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Multiplayer
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new class_500(this));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Options
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1507(new class_429(this, field_22787.field_1690));
                return true;
            }
            buttonY += buttonHeight + buttonSpacing;

            // Quit
            if (mouseX >= startX + 15 && mouseX <= startX + 15 + btnW && mouseY >= buttonY && mouseY <= buttonY + buttonHeight) {
                field_22787.method_1592();
                return true;
            }
        }

        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
