package com.acs.utils;

import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;

public class DamageUtils {
    private static final double CRYSTAL_DAMAGE_BASE = 12.0;
    private static final double CRYSTAL_FALLOFF = 0.75;
    private static final double CRYSTAL_MAX_RANGE = 12.0;
    
    private static final double SWORD_DAMAGE_BASE = 7.0;
    private static final double CRITICAL_MULTIPLIER = 1.5;
    private static final double ARMOR_REDUCTION_FACTOR = 0.04;
    private static final double ARMOR_TOUGHNESS_FACTOR = 0.02;

    /**
     * Calculate damage from an end crystal to a target player
     * @param target Target player
     * @param crystalPos Position of the crystal
     * @return Estimated damage
     */
public static float calculateCrystalDamage(class_1657 target, class_2338 crystalPos) {
    return calculateCrystalDamage(target, crystalPos, 0);
}

    /**
     * Calculate damage from an end crystal with position extrapolation
     * @param target Target player
     * @param crystalPos Position of the crystal
     * @param extrapolation Ticks to predict ahead (0 = no prediction)
     * @return Estimated damage
     */
    public static float calculateCrystalDamage(class_1657 target, class_2338 crystalPos, double extrapolation) {
        class_243 targetPos = extrapolation > 0 
            ? target.method_19538().method_1019(target.method_18798().method_1021(extrapolation / 20.0)) 
            : target.method_19538();
        
        double distToTarget = targetPos.method_1022(class_243.method_24953(crystalPos));
        
        if (distToTarget > CRYSTAL_MAX_RANGE) {
            return 0.5f;
        }
        float exposure = 1.0f - (float)(distToTarget / (6.0 * 2.0));
        float damage = (int)((exposure * exposure + exposure) / 2.0f * 7.0f * 12.0f + 1);
        
        damage = applyArmorReduction(damage, target);
        
        return Math.max(0.5f, damage);
    }

    /**
     * Calculate sword damage with optional critical hit
     * @param attacker Attacking player
     * @param target Target player
     * @param criticalHit Whether this is a critical hit
     * @return Estimated damage
     */
    public static float calculateSwordDamage(class_1657 attacker, class_1657 target, boolean criticalHit) {
        float damage = (float) SWORD_DAMAGE_BASE;
        
        if (criticalHit) {
            damage *= CRITICAL_MULTIPLIER;
        }
        
        // Apply armor reduction
        damage = applyArmorReduction(damage, target);
        
        return Math.max(0.5f, damage);
    }

    /**
     * Calculate sword damage with sharpness level
     * @param attacker Attacking player
     * @param target Target player
     * @param sharpnessLevel Sharpness enchantment level (0-5)
     * @param criticalHit Whether this is a critical hit
     * @return Estimated damage
     */
    public static float calculateSwordDamage(class_1657 attacker, class_1657 target, int sharpnessLevel, boolean criticalHit) {
        float damage = (float) SWORD_DAMAGE_BASE;
        
        damage += sharpnessLevel * 1.5f;
        
        if (criticalHit) {
            damage *= CRITICAL_MULTIPLIER;
        }
        
        damage = applyArmorReduction(damage, target);
        
        return Math.max(0.5f, damage);
    }

    /**
     * Apply armor and toughness reduction to damage
     * @param damage Base damage
     * @param target Target player with armor
     * @return Reduced damage
     */
    private static float applyArmorReduction(float damage, class_1657 target) {
        float armor = target.method_6096();
        float armorToughness = (float) target.method_45325(net.minecraft.class_5134.field_23725);

        float reduction = Math.max(armor / 5.0f, armor - damage / (2.0f + armorToughness / 4.0f));
        reduction = Math.min(reduction, 20.0f) / 25.0f;
        
        return damage * (1.0f - reduction);
    }

    /**
     * Check if damage would be lethal
     * @param damage Damage amount
     * @param target Target player
     * @return True if damage would kill the player
     */
    public static boolean isLethal(float damage, class_1657 target) {
        return damage >= target.method_6032() + target.method_6067();
    }

    /**
     * Check if damage is sufficient (above minimum threshold)
     * @param damage Damage amount
     * @param minimumDamage Minimum required damage
     * @return True if damage meets threshold
     */
    public static boolean isAboveMinimum(float damage, double minimumDamage) {
        return damage > minimumDamage;
    }
}
