package com.acs.mixin;

import net.minecraft.class_2664;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2664.class)
public interface ExplosionS2CPacketAccessor {
    @Mutable
    @Accessor("playerVelocityX")
    void setPlayerVelocityX(float playerVelocityX);

    @Mutable
    @Accessor("playerVelocityY")
    void setPlayerVelocityY(float playerVelocityY);

    @Mutable
    @Accessor("playerVelocityZ")
    void setPlayerVelocityZ(float playerVelocityZ);
}
