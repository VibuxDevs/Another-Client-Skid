package com.acs.mixin;

import com.acs.gui.hud.HudManager;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void onRender(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        HudManager.INSTANCE.render(context, tickCounter.method_60637(true));
    }
}
