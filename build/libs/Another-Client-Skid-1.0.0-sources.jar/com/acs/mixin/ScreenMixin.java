package com.acs.mixin;

import com.acs.gui.clickgui.ParticleSystem;
import net.minecraft.class_332;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_437.class)
public class ScreenMixin {
    @Unique
    private final ParticleSystem acs$particleSystem = new ParticleSystem(120);

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void onRenderBackground(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        class_437 screen = (class_437) (Object) this;
        if (net.minecraft.class_310.method_1551().field_1687 != null) {
            // In-game screen background: translucent dark red tint to keep game world visible
            context.method_25296(0, 0, screen.field_22789, screen.field_22790, 0xC00A0202, 0x80020000);
        } else {
            // Out of game screen background: full premium opaque gradient with particles
            context.method_25294(0, 0, screen.field_22789, screen.field_22790, 0xFF050505);
            context.method_25296(0, 0, screen.field_22789, screen.field_22790, 0x30FF0000, 0x05000000);
            acs$particleSystem.render(context, screen.field_22789, screen.field_22790);
        }
        ci.cancel();
    }
}
