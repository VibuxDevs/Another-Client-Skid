package com.acs.mixin;

import com.acs.gui.ACSMainMenuScreen;
import net.minecraft.class_310;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_442.class)
public class TitleScreenMixin {
    @Inject(method = "init", at = @At("HEAD"), cancellable = true)
    private void onInit(CallbackInfo ci) {
        class_310.method_1551().method_1507(new ACSMainMenuScreen());
        ci.cancel();
    }
}
