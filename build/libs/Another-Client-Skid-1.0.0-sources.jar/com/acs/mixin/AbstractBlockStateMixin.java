package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.render.XRay;
import net.minecraft.class_2248;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class_4971.class)
public class AbstractBlockStateMixin {

    @Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true)
    public void onGetRenderType(CallbackInfoReturnable<net.minecraft.class_2464> cir) {
        XRay xray = (XRay) ModuleManager.INSTANCE.getModuleByName("XRay");
        if (xray != null && xray.isEnabled()) {
            class_4970.class_4971 state = (class_4970.class_4971) (Object) this;
            class_2248 block = state.method_26204();
            if (!isSupportedBlock(block)) {
                cir.setReturnValue(net.minecraft.class_2464.field_11455);
            }
        }
    }

    @Inject(method = "isSideInvisible", at = @At("HEAD"), cancellable = true)
    public void onIsSideInvisible(class_2680 state, class_2350 direction, CallbackInfoReturnable<Boolean> cir) {
        XRay xray = (XRay) ModuleManager.INSTANCE.getModuleByName("XRay");
        if (xray != null && xray.isEnabled()) {
            class_4970.class_4971 thisState = (class_4970.class_4971) (Object) this;
            class_2248 block = thisState.method_26204();
            if (isSupportedBlock(block)) {
                cir.setReturnValue(false);
            } else {
                cir.setReturnValue(true);
            }
        }
    }

    private boolean isSupportedBlock(class_2248 block) {
        String name = net.minecraft.class_7923.field_41175.method_10221(block).method_12832();
        return name.contains("ore") || 
               name.contains("debris") || 
               name.contains("chest") || 
               name.contains("spawner") || 
               name.contains("portal") || 
               name.contains("shulker") || 
               name.contains("diamond") || 
               name.contains("emerald") || 
               name.contains("gold") || 
               name.contains("iron") || 
               name.contains("coal") || 
               name.contains("lapis") || 
               name.contains("redstone") || 
               name.contains("copper") || 
               name.contains("quartz") ||
               name.contains("raw_") ||
               name.contains("lava") ||
               name.contains("water");
    }
}
