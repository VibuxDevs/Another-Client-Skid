package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.movement.ElytraFly;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1309.class)
public class LivingEntityMixin {

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    public void onTravel(class_243 movementInput, CallbackInfo ci) {
        if ((Object) this instanceof class_746 player) {
            com.acs.module.modules.movement.ElytraFly elytraFly = (com.acs.module.modules.movement.ElytraFly) ModuleManager.INSTANCE.getModuleByName("ElytraFly");
            if (elytraFly != null && elytraFly.isEnabled() && player.method_6128()) {
                elytraFly.handleTravel(player);
                ci.cancel();
            }
        }
    }
}
