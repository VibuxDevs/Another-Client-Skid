package com.acs.mixin;

import com.acs.module.Module;
import com.acs.module.ModuleManager;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {
    @Shadow private int itemUseCooldown;

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (class_310.method_1551().field_1724 != null) {
            Module fastPlace = ModuleManager.INSTANCE.getModuleByName("FastPlace");
            if (fastPlace != null && fastPlace.isEnabled()) {
                itemUseCooldown = 0;
            }

            for (Module module : ModuleManager.INSTANCE.getModules()) {
                if (module.isEnabled()) {
                    module.onTick();
                }
            }
        }
    }
}
