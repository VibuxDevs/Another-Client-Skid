package com.acs.mixin;

import com.acs.module.Module;
import com.acs.module.ModuleManager;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_442;
import com.acs.gui.ACSMainMenuScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_310.class)
public class MinecraftClientMixin {
    @Shadow private int itemUseCooldown;

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private class_437 modifyScreen(class_437 screen) {
        if (screen instanceof class_442 && !(screen instanceof ACSMainMenuScreen)) {
            return new ACSMainMenuScreen();
        }
        return screen;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (class_310.method_1551().field_1724 != null) {
            for (Module module : ModuleManager.INSTANCE.getModules()) {
                if (module.isEnabled()) {
                    module.onTick();
                }
            }
            
            com.acs.module.modules.player.FastPlace fastPlace = (com.acs.module.modules.player.FastPlace) ModuleManager.INSTANCE.getModuleByName("FastPlace");
            if (fastPlace != null && fastPlace.isEnabled()) {
                if (itemUseCooldown > fastPlace.getDelay()) {
                    itemUseCooldown = fastPlace.getDelay();
                }
            }
        }
    }
}
