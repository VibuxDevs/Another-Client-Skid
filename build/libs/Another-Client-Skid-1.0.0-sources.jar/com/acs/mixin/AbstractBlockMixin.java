package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.render.XRay;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4970;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_4970.class)
public class AbstractBlockMixin {

    @Inject(method = "getAmbientOcclusionLightLevel", at = @At("HEAD"), cancellable = true)
    public void onGetAmbientOcclusionLightLevel(class_2680 state, class_1922 world, class_2338 pos, CallbackInfoReturnable<Float> cir) {
        XRay xray = (XRay) ModuleManager.INSTANCE.getModuleByName("XRay");
        if (xray != null && xray.isEnabled()) {
            cir.setReturnValue(1.0f);
        }
    }
}
