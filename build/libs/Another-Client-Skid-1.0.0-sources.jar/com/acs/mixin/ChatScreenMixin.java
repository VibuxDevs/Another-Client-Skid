package com.acs.mixin;

import net.minecraft.class_342;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_408.class)
public class ChatScreenMixin {

    @Shadow
    protected class_342 chatField;

    private String currentSuggestion = null;

    @Inject(method = "updateCommandSuggestions", at = @At("HEAD"), cancellable = true)
    private void onUpdateSuggestions(CallbackInfo ci) {
        String text = chatField.method_1882();
        if (!text.startsWith(".")) return;

        String partial = text.substring(1).toLowerCase();
        String[] knownCommands = {"toggle", "t", "bind", "b", "config", "cfg", "help", "h"};

        currentSuggestion = null;
        for (String cmd : knownCommands) {
            if (cmd.startsWith(partial) && !cmd.equals(partial)) {
                currentSuggestion = "." + cmd;
                break;
            }
        }

        if (currentSuggestion != null && partial.length() > 0) {
            chatField.method_1887(currentSuggestion.substring(text.length()));
        } else {
            chatField.method_1887(null);
        }

        ci.cancel();
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void onKeyPressed(int keyCode, int scanCode, int modifiers, CallbackInfoReturnable<Boolean> cir) {
        if (keyCode != 258) return;

        String text = chatField.method_1882();
        if (!text.startsWith(".")) return;

        if (currentSuggestion != null) {
            chatField.method_1852(currentSuggestion);
            chatField.method_1872(false);
            chatField.method_1887(null);
            currentSuggestion = null;
            cir.setReturnValue(true);
        }
    }
}