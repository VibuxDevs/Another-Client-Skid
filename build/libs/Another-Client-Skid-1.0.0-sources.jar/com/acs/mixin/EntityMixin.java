package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.movement.Velocity;
import com.acs.module.modules.render.ESP;
import net.minecraft.class_1297;
import net.minecraft.class_1429;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class EntityMixin {

    @Inject(method = "addVelocity", at = @At("HEAD"), cancellable = true)
    public void onAddVelocity(net.minecraft.class_243 velocityVector, CallbackInfo ci) {
        class_1297 entity = (class_1297) (Object) this;
        // Basic Velocity check for the player
        if (entity instanceof class_1657 && entity.method_5667().equals(net.minecraft.class_310.method_1551().method_1548().method_44717())) {
            Velocity velocity = (Velocity) ModuleManager.INSTANCE.getModuleByName("Velocity");
            if (velocity != null && velocity.isEnabled()) {
                double horizontal = velocity.getHorizontal();
                double vertical = velocity.getVertical();
                
                if (horizontal == 0.0 && vertical == 0.0) {
                    ci.cancel();
                } else {
                    entity.method_18799(entity.method_18798().method_1031(velocityVector.field_1352 * horizontal, velocityVector.field_1351 * vertical, velocityVector.field_1350 * horizontal));
                    entity.field_6037 = true;
                    ci.cancel();
                }
            }
        }
    }

    @Inject(method = "isGlowing", at = @At("HEAD"), cancellable = true)
    private void onIsGlowing(CallbackInfoReturnable<Boolean> cir) {
        ESP esp = (ESP) ModuleManager.INSTANCE.getModuleByName("ESP");
        if (esp != null && esp.isEnabled()) {
            class_1297 entity = (class_1297) (Object) this;
            if (entity instanceof class_1657 && esp.shouldRenderPlayers()) {
                cir.setReturnValue(true);
            } else if (entity instanceof class_1588 && esp.shouldRenderMobs()) {
                cir.setReturnValue(true);
            } else if (entity instanceof class_1429 && esp.shouldRenderAnimals()) {
                cir.setReturnValue(true);
            } else if (entity instanceof class_1542 && esp.shouldRenderItems()) {
                cir.setReturnValue(true);
            }
        }
    }
}
