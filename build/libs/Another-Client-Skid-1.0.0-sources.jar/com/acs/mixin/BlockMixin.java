package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.render.XRay;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2248.class)
public class BlockMixin {

    @Inject(method = "shouldDrawSide", at = @At("HEAD"), cancellable = true)
    private static void onShouldDrawSide(class_2680 state, class_1922 world, class_2338 pos, class_2350 side, class_2338 blockPos, CallbackInfoReturnable<Boolean> cir) {
        XRay xray = (XRay) ModuleManager.INSTANCE.getModuleByName("XRay");
        if (xray != null && xray.isEnabled()) {
            class_2248 block = state.method_26204();
            String name = net.minecraft.class_7923.field_41175.method_10221(block).method_12832();
            if (name.contains("ore") || name.contains("ancient_debris") || name.contains("diamond") || name.contains("emerald") || name.contains("gold") || name.contains("iron") || name.contains("coal") || name.contains("lapis") || name.contains("redstone")) {
                cir.setReturnValue(true);
            } else {
                cir.setReturnValue(false);
            }
        }
    }
}
