package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.render.Freecam;
import net.minecraft.class_2535;
import net.minecraft.class_2596;
import net.minecraft.class_2828;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2535.class)
public class ClientConnectionMixin {

    @Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true)
    public void onSendPacket(class_2596<?> packet, CallbackInfo ci) {
        com.acs.module.modules.exploits.Blink blink = (com.acs.module.modules.exploits.Blink) ModuleManager.INSTANCE.getModuleByName("Blink");
        if (blink != null && blink.isEnabled()) {
            if (blink.onSendPacket(packet)) {
                ci.cancel();
                return;
            }
        }

        Freecam freecam = (Freecam) ModuleManager.INSTANCE.getModuleByName("Freecam");
        if (freecam != null && freecam.isEnabled()) {
            if (packet instanceof class_2828) {
                ci.cancel();
                return;
            }
        }

        com.acs.module.modules.exploits.ReverseGhostBlock rgb = (com.acs.module.modules.exploits.ReverseGhostBlock) ModuleManager.INSTANCE.getModuleByName("ReverseGhostBlock");
        if (rgb != null && rgb.isEnabled()) {
            if (packet instanceof net.minecraft.class_2885 interactPacket) {
                net.minecraft.class_3965 hit = interactPacket.method_12543();
                if (hit != null) {
                    net.minecraft.class_2338 targetPos = hit.method_17777();
                    net.minecraft.class_2350 side = hit.method_17780();
                    net.minecraft.class_2338 placedPos = targetPos.method_10093(side);
                    rgb.addGhostBlock(placedPos);
                }
            }
        }
        
        com.acs.module.modules.player.NoFall noFall = (com.acs.module.modules.player.NoFall) ModuleManager.INSTANCE.getModuleByName("NoFall");
        if (noFall != null && noFall.isEnabled()) {
            if (packet instanceof class_2828 movePacket) {
                if (net.minecraft.class_310.method_1551().field_1724 != null && net.minecraft.class_310.method_1551().field_1724.field_6017 > 3.0f) {
                    ((PlayerMoveC2SPacketAccessor) movePacket).setOnGround(true);
                }
            }
        }
    }
}
