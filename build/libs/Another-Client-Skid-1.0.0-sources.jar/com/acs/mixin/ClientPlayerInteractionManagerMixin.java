package com.acs.mixin;

import com.acs.module.Module;
import com.acs.module.ModuleManager;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2828;
import net.minecraft.class_310;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_636.class)
public class ClientPlayerInteractionManagerMixin {
    @Inject(method = "attackEntity", at = @At("HEAD"))
    private void onAttackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
        Module maceKill = ModuleManager.INSTANCE.getModuleByName("MaceKill");
        if (maceKill != null && maceKill.isEnabled()) {
            class_310 mc = class_310.method_1551();
            if (mc.field_1724 != null && mc.field_1724.method_6047().method_7909() == class_1802.field_49814) {
                double height = 20.0;
                com.acs.settings.Setting<?> heightSetting = maceKill.getSettings().stream()
                        .filter(s -> s.getName().equalsIgnoreCase("Height"))
                        .findFirst().orElse(null);
                if (heightSetting != null && heightSetting.getValue() instanceof Double) {
                    height = (Double) heightSetting.getValue();
                }

                double x = mc.field_1724.method_23317();
                double y = mc.field_1724.method_23318();
                double z = mc.field_1724.method_23321();

                // Spoof the server into thinking we fell from high up to trigger Mace critical damage
                if (mc.field_1724.field_3944 != null) {
                    mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y + height, z, false));
                    mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y, z, false));
                }
            }
        }
    }
}
