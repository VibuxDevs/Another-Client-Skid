package com.acs.mixin;

import com.acs.module.ModuleManager;
import com.acs.module.modules.movement.Velocity;
import net.minecraft.class_2604;
import net.minecraft.class_2626;
import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    public void onEntityVelocityUpdate(class_2743 packet, CallbackInfo ci) {
        if (class_310.method_1551().field_1724 == null) return;
        
        if (packet.method_11818() == class_310.method_1551().field_1724.method_5628()) {
            Velocity velocity = (Velocity) ModuleManager.INSTANCE.getModuleByName("Velocity");
            if (velocity != null && velocity.isEnabled()) {
                double horizontal = velocity.getHorizontal();
                double vertical = velocity.getVertical();
                
                if (horizontal == 0.0 && vertical == 0.0) {
                    ci.cancel();
                } else {
                    double vx = (packet.method_11815() / 8000.0D) * horizontal;
                    double vy = (packet.method_11816() / 8000.0D) * vertical;
                    double vz = (packet.method_11819() / 8000.0D) * horizontal;
                    class_310.method_1551().field_1724.method_18800(vx, vy, vz);
                    ci.cancel();
                }
            }
        }
    }

    @Inject(method = "onExplosion", at = @At("HEAD"))
    public void onExplosion(class_2664 packet, CallbackInfo ci) {
        com.acs.module.modules.exploits.CoordLogger coordLogger = (com.acs.module.modules.exploits.CoordLogger) ModuleManager.INSTANCE.getModuleByName("CoordLogger");
        if (coordLogger != null) {
            coordLogger.handleExplosion(packet.method_11475(), packet.method_11477(), packet.method_11478());
        }

        Velocity velocity = (Velocity) ModuleManager.INSTANCE.getModuleByName("Velocity");
        if (velocity != null && velocity.isEnabled() && velocity.handleExplosions()) {
            double horizontal = velocity.getHorizontal();
            double vertical = velocity.getVertical();
            
            ExplosionS2CPacketAccessor accessor = (ExplosionS2CPacketAccessor) packet;
            accessor.setPlayerVelocityX((float) (packet.method_11472() * horizontal));
            accessor.setPlayerVelocityY((float) (packet.method_11473() * vertical));
            accessor.setPlayerVelocityZ((float) (packet.method_11474() * horizontal));
        }
    }

    @Inject(method = "onPlaySound", at = @At("HEAD"))
    public void onPlaySound(net.minecraft.class_2767 packet, CallbackInfo ci) {
        com.acs.module.modules.exploits.CoordLogger coordLogger = (com.acs.module.modules.exploits.CoordLogger) ModuleManager.INSTANCE.getModuleByName("CoordLogger");
        if (coordLogger != null) {
            coordLogger.handleSound(packet.method_11894(), packet.method_11890(), packet.method_11889(), packet.method_11893());
        }
    }

    @Inject(method = "onWorldEvent", at = @At("HEAD"))
    public void onWorldEvent(net.minecraft.class_2673 packet, CallbackInfo ci) {
        com.acs.module.modules.exploits.CoordLogger coordLogger = (com.acs.module.modules.exploits.CoordLogger) ModuleManager.INSTANCE.getModuleByName("CoordLogger");
        if (coordLogger != null) {
            coordLogger.handleWorldEvent(packet.method_11532(), packet.method_11531());
        }
    }

    @Inject(method = "onEntitySpawn", at = @At("HEAD"))
    public void onEntitySpawn(class_2604 packet, CallbackInfo ci) {
        com.acs.module.modules.exploits.Randar randar = (com.acs.module.modules.exploits.Randar) ModuleManager.INSTANCE.getModuleByName("Randar");
        if (randar != null) {
            randar.handleEntitySpawn(packet);
        }
    }

    @Inject(method = "onBlockUpdate", at = @At("HEAD"))
    public void onBlockUpdate(class_2626 packet, CallbackInfo ci) {
        com.acs.module.modules.exploits.Nocom nocom = (com.acs.module.modules.exploits.Nocom) ModuleManager.INSTANCE.getModuleByName("Nocom");
        if (nocom != null) {
            nocom.handleBlockUpdate(packet);
        }
    }
}
