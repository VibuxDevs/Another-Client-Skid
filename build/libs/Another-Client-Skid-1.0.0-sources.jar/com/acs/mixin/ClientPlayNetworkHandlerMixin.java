package com.acs.mixin;

import com.acs.module.Module;
import com.acs.module.ModuleManager;
import net.minecraft.class_2664;
import net.minecraft.class_2743;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_634.class)
public class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void onEntityVelocityUpdate(class_2743 packet, CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && packet.method_11818() == mc.field_1724.method_5628()) {
            Module velocity = ModuleManager.INSTANCE.getModuleByName("Velocity");
            if (velocity != null && velocity.isEnabled()) {
                ci.cancel();
            }
        }
    }

    @Inject(method = "onExplosion", at = @At("HEAD"), cancellable = true)
    private void onExplosion(class_2664 packet, CallbackInfo ci) {
        Module velocity = ModuleManager.INSTANCE.getModuleByName("Velocity");
        if (velocity != null && velocity.isEnabled()) {
            ci.cancel();
        }
    }
}
