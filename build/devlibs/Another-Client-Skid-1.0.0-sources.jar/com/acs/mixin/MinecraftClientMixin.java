package com.acs.mixin;

import com.acs.module.Module;
import com.acs.module.ModuleManager;
import com.acs.gui.ACSMainMenuScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Shadow private int itemUseCooldown;

    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private Screen modifyScreen(Screen screen) {
        if (screen instanceof TitleScreen && !(screen instanceof ACSMainMenuScreen)) {
            return new ACSMainMenuScreen();
        }
        return screen;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        if (MinecraftClient.getInstance().player != null) {
            for (Module module : ModuleManager.INSTANCE.getModules()) {
                if (module.isEnabled()) {
                    module.onTick();
                }
            }
            
            com.acs.module.modules.player.FastPlace fastPlace = (com.acs.module.modules.player.FastPlace) ModuleManager.INSTANCE.getModuleByName("FastPlace");
            if (fastPlace != null && fastPlace.isEnabled()) {
                if (itemUseCooldown > fastPlace.getDelay()) {
                    itemUseCooldown = fastPlace.getDelay();
                }
            }
        }
    }
}
