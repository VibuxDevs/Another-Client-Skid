package com.acs.module.modules;

import com.acs.module.Category;
import com.acs.module.Module;
import net.minecraft.client.option.SimpleOption;

import java.lang.reflect.Field;

public class Fullbright extends Module {
    private double savedGamma = 1.0;

    public Fullbright() {
        super("Fullbright", "Makes everything bright", Category.RENDER);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            savedGamma = mc.options.getGamma().getValue();
            setGamma(16.0);
        }
    }

    @Override
    public void onTick() {
        if (mc.options != null) {
            setGamma(16.0);
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null) {
            setGamma(savedGamma);
        }
    }

    @SuppressWarnings("unchecked")
    private void setGamma(double value) {
        try {
            SimpleOption<Double> gamma = mc.options.getGamma();
            Field field = SimpleOption.class.getDeclaredField("value");
            field.setAccessible(true);
            field.set(gamma, value);
        } catch (Exception e) {
            // Reflection failed, try setValue anyway
            mc.options.getGamma().setValue(value);
        }
    }
}
